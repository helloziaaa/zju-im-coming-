import { Component, useCallback, useState } from "react";
import type { ReactNode } from "react";
import { StoreProvider, drawDaily, drawMistakes, useStore } from "./lib/store";
import type { QuizConfig } from "./types";
import { Sidebar } from "./components/Sidebar";
import type { Tab } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { Quiz } from "./components/Quiz";
import { WeeklyReview } from "./components/WeeklyReview";
import { MistakeBook } from "./components/MistakeBook";
import { Bank } from "./components/Bank";
import { StatsPage } from "./components/StatsPage";
import { ImportPage } from "./components/ImportPage";

function Shell() {
  const { state, d } = useStore();
  const [tab, setTabRaw] = useState<Tab>("home");
  const [quiz, setQuiz] = useState<QuizConfig | null>(null);

  const setTab = useCallback((t: Tab) => {
    setQuiz(null);
    setTabRaw(t);
    window.scrollTo({ top: 0 });
  }, []);

  const launch = useCallback((cfg: QuizConfig) => {
    setQuiz(cfg);
    window.scrollTo({ top: 0 });
  }, []);

  const again = useCallback(() => {
    if (!quiz) return;
    let ids: string[] = [];
    if (quiz.type === "weekly") ids = d.weekWrongIds;
    else if (quiz.type === "review") ids = drawMistakes(state.questions).map((q) => q.id);
    else ids = drawDaily(state.questions).map((q) => q.id);
    if (quiz.type === "review" && ids.length === 0) ids = drawDaily(state.questions).map((q) => q.id);
    if (ids.length === 0) {
      setQuiz(null);
      return;
    }
    setQuiz({ ...quiz, ids });
    window.scrollTo({ top: 0 });
  }, [quiz, state.questions, d.weekWrongIds]);

  return (
    <div className="min-h-screen lg:pl-60">
      <Sidebar tab={tab} setTab={setTab} />

      {/* 作业本红色页边线 */}
      <div className="pointer-events-none fixed inset-y-0 left-60 z-30 hidden w-[2px] bg-pen/20 lg:block" />

      <main className="px-4 pb-16 pt-32 sm:px-8 lg:px-10 lg:pt-10">
        <div className="mx-auto max-w-6xl">
          {quiz ? (
            <Quiz key={`${quiz.type}-${quiz.ids.join(".")}`} cfg={quiz} onExit={() => setQuiz(null)} onAgain={again} />
          ) : (
            <>
              {tab === "home" && <Dashboard launch={launch} goto={setTab} />}
              {tab === "weekly" && <WeeklyReview launch={launch} />}
              {tab === "mistakes" && <MistakeBook launch={launch} />}
              {tab === "bank" && <Bank goto={setTab} />}
              {tab === "stats" && <StatsPage />}
              {tab === "import" && <ImportPage goto={setTab} />}
            </>
          )}
        </div>
      </main>

      <footer className="border-t border-line px-4 py-6 text-center text-[11px] leading-relaxed text-ink-faint sm:px-8">
        红笔刷题 · 数据仅保存在本地浏览器 · PDF 全程本地解析不上传 · 标红即答案 · 每日 15 题 → 周复盘 → 整库轮刷至 99%
      </footer>
    </div>
  );
}

class ErrorBoundary extends Component<{ children: ReactNode }, { err: Error | null }> {
  state = { err: null as Error | null };
  static getDerivedStateFromError(err: Error) {
    return { err };
  }
  render() {
    if (this.state.err) {
      return (
        <div className="flex min-h-screen items-center justify-center bg-paper p-6" style={{ fontFamily: "'Noto Sans SC', sans-serif" }}>
          <div className="w-full max-w-lg border-2 border-pen bg-card p-8" style={{ boxShadow: "4px 4px 0 rgba(33,30,25,0.9)" }}>
            <p className="text-[11px] font-bold tracking-[0.3em] text-pen">运行时错误</p>
            <h1 className="mt-2 text-2xl font-black text-ink">页面加载出了问题</h1>
            <p className="mt-3 border border-dashed border-line bg-paper p-3 font-mono text-xs leading-relaxed text-ink-soft">
              {String(this.state.err?.message ?? this.state.err)}
            </p>
            <div className="mt-5 flex gap-3">
              <button
                onClick={() => location.reload()}
                className="border-2 border-ink bg-pen px-5 py-2.5 text-sm font-bold text-paper"
              >
                刷新重试
              </button>
              <button
                onClick={() => {
                  localStorage.removeItem("hongbi-shuati-v1");
                  location.reload();
                }}
                className="border-2 border-ink bg-card px-5 py-2.5 text-sm font-bold text-ink"
              >
                清空本地数据并刷新
              </button>
            </div>
            <p className="mt-4 text-xs text-ink-faint">若反复出现，请尝试更换 Chrome / Edge 最新版浏览器打开。</p>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  return (
    <ErrorBoundary>
      <StoreProvider>
        <Shell />
      </StoreProvider>
    </ErrorBoundary>
  );
}
