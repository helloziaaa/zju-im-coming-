import { createContext, useContext, useEffect, useMemo, useReducer } from "react";
import type { Dispatch, ReactNode } from "react";
import { v4 as uuidv4 } from "uuid";
import type { AppState, Question, SessionRecord, SessionType, StreakInfo } from "../types";
import type { ParsedQuestion } from "./parser";
import { SAMPLE_QUESTIONS } from "./sample";

const LS_KEY = "hongbi-shuati-v1";

export const DAILY_COUNT = 15;
export const GOAL_ACCURACY = 0.99;

/* ---------------- reducer ---------------- */

export type Action =
  | { type: "IMPORT"; questions: Question[] }
  | { type: "DELETE"; id: string }
  | { type: "RESET_STATS"; id: string }
  | { type: "CLEAR_SAMPLE" }
  | { type: "LOAD_SAMPLE" }
  | { type: "RECORD"; session: SessionRecord }
  | { type: "RESET_ALL" };

export function dateKey(t: number): string {
  const d = new Date(t);
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function normalizeStem(s: string): string {
  return s.replace(/[\s\u3000，。、；：！？,.:;!?（）()[\]【】"'“”‘’·\-—…~～\d.、．)）A-Fa-f]/g, "");
}

const ZERO_STREAK: StreakInfo = { lastDate: "", count: 0, totalDays: 0 };

function loadInitial(): AppState {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppState;
      if (parsed && Array.isArray(parsed.questions)) {
        return { ...parsed, streak: parsed.streak ?? ZERO_STREAK };
      }
    }
  } catch {
    /* 忽略损坏数据 */
  }
  return {
    questions: SAMPLE_QUESTIONS,
    sessions: [],
    cycle: 1,
    cycleStartAt: Date.now(),
    cycleHistory: [],
    seededSample: true,
    streak: ZERO_STREAK,
  };
}

function nextStreak(prev: StreakInfo, today: string, yesterday: string): StreakInfo {
  if (prev.lastDate === today) return prev;
  if (prev.lastDate === yesterday) return { lastDate: today, count: prev.count + 1, totalDays: prev.totalDays + 1 };
  return { lastDate: today, count: 1, totalDays: prev.totalDays + 1 };
}

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case "IMPORT": {
      const exist = new Set(state.questions.map((q) => normalizeStem(q.stem)));
      const fresh = action.questions.filter((q) => !exist.has(normalizeStem(q.stem)));
      return { ...state, questions: [...state.questions, ...fresh] };
    }
    case "DELETE":
      return { ...state, questions: state.questions.filter((q) => q.id !== action.id) };
    case "RESET_STATS":
      return {
        ...state,
        questions: state.questions.map((q) =>
          q.id === action.id
            ? {
                ...q,
                attempts: 0,
                correct: 0,
                wrongCount: 0,
                consecutiveCorrect: 0,
                mastered: false,
                seenThisCycle: false,
                lastAttemptAt: undefined,
                lastWrongAt: undefined,
              }
            : q,
        ),
      };
    case "CLEAR_SAMPLE":
      return { ...state, questions: state.questions.filter((q) => !q.sample), seededSample: false };
    case "LOAD_SAMPLE": {
      const exist = new Set(state.questions.map((q) => q.id));
      const fresh = SAMPLE_QUESTIONS.filter((q) => !exist.has(q.id));
      return { ...state, questions: [...state.questions, ...fresh], seededSample: true };
    }
    case "RECORD": {
      const s = action.session;
      const wrongSet = new Set(s.wrongIds);
      const questions = state.questions.map((q) => {
        if (!s.order.includes(q.id)) return q;
        const ok = !wrongSet.has(q.id);
        const consecutiveCorrect = ok ? q.consecutiveCorrect + 1 : 0;
        return {
          ...q,
          attempts: q.attempts + 1,
          correct: q.correct + (ok ? 1 : 0),
          consecutiveCorrect,
          mastered: consecutiveCorrect >= 2,
          wrongCount: q.wrongCount + (ok ? 0 : 1),
          seenThisCycle: true,
          lastAttemptAt: s.finishedAt,
          lastWrongAt: ok ? q.lastWrongAt : s.finishedAt,
        };
      });

      const today = s.dateKey;
      const yesterday = dateKey(s.finishedAt - 86400000);
      const streak = nextStreak(state.streak, today, yesterday);

      // 轮次：整库练完一遍 → 记录本轮，进入新一轮（seenThisCycle 全部清零重刷）
      let cycle = state.cycle;
      let cycleStartAt = state.cycleStartAt;
      let cycleHistory = state.cycleHistory;
      let resetSeen = false;
      if (questions.length > 0 && questions.every((q) => q.seenThisCycle)) {
        cycleHistory = [...cycleHistory, { cycle, at: s.finishedAt, accuracy: s.accuracy }];
        cycle += 1;
        cycleStartAt = s.finishedAt;
        resetSeen = true;
      }

      return {
        ...state,
        questions: resetSeen ? questions.map((q) => ({ ...q, seenThisCycle: false })) : questions,
        sessions: [s, ...state.sessions].slice(0, 300),
        streak,
        cycle,
        cycleStartAt,
        cycleHistory,
      };
    }
    case "RESET_ALL":
      return { questions: [], sessions: [], cycle: 1, cycleStartAt: Date.now(), cycleHistory: [], seededSample: false, streak: ZERO_STREAK };
    default:
      return state;
  }
}

/* ---------------- 派生数据 ---------------- */

export interface Derived {
  attempts: number;
  correctCount: number;
  accuracy: number;
  goalReached: boolean;
  needCorrect: number;
  unseenCount: number;
  masteredCount: number;
  wrongQuestions: Question[];
  weekWrongIds: string[];
  dailyDone: SessionRecord | null;
  streak: StreakInfo;
  cycleSeenCount: number;
}

function derive(state: AppState): Derived {
  let attempts = 0;
  let correctCount = 0;
  for (const q of state.questions) {
    attempts += q.attempts;
    correctCount += q.correct;
  }
  const accuracy = attempts > 0 ? correctCount / attempts : 0;
  const goalReached = accuracy >= GOAL_ACCURACY && attempts >= 30;
  const needCorrect = attempts === 0 ? 0 : Math.max(0, Math.ceil((GOAL_ACCURACY * attempts - correctCount) / (1 - GOAL_ACCURACY)));

  const now = Date.now();
  const weekAgo = now - 7 * 86400000;
  const weekWrong = new Set<string>();
  for (const s of state.sessions) {
    if (s.finishedAt >= weekAgo) for (const id of s.wrongIds) weekWrong.add(id);
  }
  const ids = new Set(state.questions.map((q) => q.id));
  const weekWrongIds = Array.from(weekWrong).filter((id) => ids.has(id));

  const todayKey = dateKey(now);
  const dailyDone = state.sessions.find((s) => s.type === "daily" && s.dateKey === todayKey) ?? null;

  const wrongQuestions = state.questions
    .filter((q) => q.wrongCount > 0)
    .sort((a, b) => (b.lastWrongAt ?? 0) - (a.lastWrongAt ?? 0));

  return {
    attempts,
    correctCount,
    accuracy,
    goalReached,
    needCorrect,
    unseenCount: state.questions.filter((q) => !q.seenThisCycle).length,
    masteredCount: state.questions.filter((q) => q.mastered).length,
    wrongQuestions,
    weekWrongIds,
    dailyDone,
    streak: state.streak,
    cycleSeenCount: state.questions.filter((q) => q.seenThisCycle).length,
  };
}

/* ---------------- 抽题策略 ---------------- */

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** 每日抽题：优先本轮新题 → 历史错题 → 已练题，随机组合 */
export function drawDaily(qs: Question[], n = DAILY_COUNT): Question[] {
  const unseen = shuffle(qs.filter((q) => !q.seenThisCycle));
  const wrong = shuffle(qs.filter((q) => q.seenThisCycle && q.wrongCount > 0));
  const rest = shuffle(qs.filter((q) => q.seenThisCycle && q.wrongCount === 0));
  return [...unseen, ...wrong, ...rest].slice(0, n);
}

/** 错题重练：错得越多越靠前 */
export function drawMistakes(qs: Question[], n = DAILY_COUNT): Question[] {
  const pool = qs.filter((q) => q.wrongCount > 0);
  return shuffle(pool)
    .sort((a, b) => b.wrongCount - a.wrongCount)
    .slice(0, n);
}

export function makeQuestion(p: ParsedQuestion, source: string): Question {
  return {
    id: uuidv4(),
    stem: p.stem,
    options: p.options.map((o) => ({ key: o.key, text: o.text })),
    answer: p.answer,
    explanation: p.explanation,
    source,
    createdAt: Date.now(),
    attempts: 0,
    correct: 0,
    wrongCount: 0,
    consecutiveCorrect: 0,
    mastered: false,
    seenThisCycle: false,
  };
}

/* ---------------- context ---------------- */

interface StoreCtx {
  state: AppState;
  d: Derived;
  dispatch: Dispatch<Action>;
  recordSession: (type: SessionType, order: string[], answers: Record<string, string[]>) => SessionRecord;
}

const Ctx = createContext<StoreCtx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, undefined, loadInitial);

  useEffect(() => {
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(state));
    } catch {
      /* 存储已满等情况静默处理 */
    }
  }, [state]);

  const d = useMemo(() => derive(state), [state]);

  const ctx = useMemo<StoreCtx>(() => {
    return {
      state,
      d,
      dispatch,
      recordSession: (type, order, answers) => {
        const qmap = new Map(state.questions.map((q) => [q.id, q]));
        const wrongIds: string[] = [];
        let correct = 0;
        for (const qid of order) {
          const q = qmap.get(qid);
          if (!q) continue;
          const sel = [...(answers[qid] ?? [])].sort().join("");
          const ans = q.answer.join("");
          if (sel === ans && sel.length > 0) correct++;
          else wrongIds.push(qid);
        }
        const now = Date.now();
        const session: SessionRecord = {
          id: uuidv4(),
          type,
          order,
          answers,
          wrongIds,
          correctCount: correct,
          total: order.length,
          accuracy: order.length > 0 ? correct / order.length : 0,
          finishedAt: now,
          dateKey: dateKey(now),
        };
        dispatch({ type: "RECORD", session });
        return session;
      },
    };
  }, [state, d]);

  return <Ctx.Provider value={ctx}>{children}</Ctx.Provider>;
}

export function useStore(): StoreCtx {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStore must be used within StoreProvider");
  return v;
}

export function isCorrect(q: Question, selected: string[] | undefined): boolean {
  const sel = [...(selected ?? [])].sort().join("");
  return sel === q.answer.join("") && sel.length > 0;
}
