/* 题目解析：把「带红字标注的行」解析成结构化题目。
   支持格式：
   1. 题号行：  1. / 1、 / 1． / 第3题
   2. 选项行：  A. / A、 / A． / A: 
   3. 答案行：  答案：ABC / 【答案】ABC（或整行为红色字体）
   4. 解析行：  解析：…… / 【解析】……
   5. PDF 中整行选项为红色 → 该选项为正确选项；答案字母为红色 → 识别为答案 */

export interface LineSeg {
  text: string;
  red: boolean;
}

export interface ParsedLine {
  text: string;
  redRatio: number;
  redText: string;
  segs: LineSeg[];
}

export interface ParsedOption {
  key: string;
  text: string;
  red: boolean;
}

export interface ParsedQuestion {
  num: number;
  stem: string;
  options: ParsedOption[];
  answer: string[];
  explanation: string;
  errors: string[];
}

export interface ParseResult {
  questions: ParsedQuestion[];
  valid: ParsedQuestion[];
  invalid: ParsedQuestion[];
  redDetected: boolean;
}

const RE_Q = /^(\d{1,3})\s*[.、．)）]\s*(.+)$/;
const RE_Q2 = /^第\s*([0-9一二三四五六七八九十百]+)\s*题\s*[.、．:：]?\s*(.*)$/;
const RE_OPT = /^([A-Fa-f])\s*[.、．:：)）]\s*(.+)$/;
const RE_ANS = /^(?:【\s*答\s*案\s*】|答\s*案)\s*[：:]?\s*([A-Fa-f,，、\s]*)\s*$/;
const RE_EXP = /^(?:【\s*解\s*析\s*】|解\s*析)\s*[：:]?\s*(.*)$/;

const CN_NUM: Record<string, number> = {
  一: 1, 二: 2, 三: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9, 十: 10,
  十一: 11, 十二: 12, 十三: 13, 十四: 14, 十五: 15, 二十: 20,
};

export function textToLines(text: string): ParsedLine[] {
  return text
    .split(/\r?\n/)
    .map((raw) => raw.trim())
    .filter((t) => t.length > 0)
    .map((t) => ({ text: t, redRatio: 0, redText: "", segs: [{ text: t, red: false }] }));
}

interface Draft {
  num: number;
  stem: string;
  options: ParsedOption[];
  explanation: string;
  explicitAnswer: string;
  redLetters: Set<string>;
  block: "stem" | "option" | "exp" | "none";
  blockKey: string;
}

function extractRedLetters(line: ParsedLine): string[] {
  const red = line.segs.filter((s) => s.red).map((s) => s.text).join("");
  return (red.match(/[A-Fa-f]/g) ?? []).map((c) => c.toUpperCase());
}

export function parseLines(lines: ParsedLine[], redAvailable: boolean): ParseResult {
  const drafts: Draft[] = [];
  let cur: Draft | null = null;
  let autoNum = 0;
  let redDetected = false;

  const push = (d: Draft) => drafts.push(d);

  for (const line of lines) {
    const t = line.text.replace(/\u3000/g, " ").trim();
    if (!t) continue;
    if (line.redRatio > 0) redDetected = true;

    const mq = t.match(RE_Q) ?? t.match(RE_Q2);
    if (mq && !RE_OPT.test(t)) {
      if (cur) push(cur);
      const rawNum = mq[1];
      const num = /^\d+$/.test(rawNum) ? parseInt(rawNum, 10) : CN_NUM[rawNum] ?? ++autoNum;
      autoNum = Math.max(autoNum, num);
      cur = {
        num,
        stem: (mq[2] ?? "").trim(),
        options: [],
        explanation: "",
        explicitAnswer: "",
        redLetters: new Set(),
        block: "stem",
        blockKey: "",
      };
      continue;
    }

    const ma = t.match(RE_ANS);
    if (cur && ma) {
      cur.explicitAnswer += (ma[1] ?? "").replace(/[,，、\s]+/g, "");
      cur.block = "none";
      continue;
    }

    const me = t.match(RE_EXP);
    if (cur && me) {
      cur.explanation += (me[1] ?? "").trim();
      cur.block = "exp";
      continue;
    }

    const mo = t.match(RE_OPT);
    if (cur && mo) {
      cur.options.push({
        key: mo[1].toUpperCase(),
        text: mo[2].trim(),
        red: line.redRatio > 0.5,
      });
      cur.block = "option";
      cur.blockKey = mo[1].toUpperCase();
      continue;
    }

    // 延续行：并入当前块
    if (cur) {
      if (cur.block === "stem") cur.stem += t;
      else if (cur.block === "exp") cur.explanation += t;
      else if (cur.block === "option" && cur.options.length > 0) {
        cur.options[cur.options.length - 1].text += t;
      }
    }

    // 收集红字中的答案字母（整行是选项行时不在此处收集，选项红字走 red 判定）
    if (cur && !(cur.block === "option" && line.redRatio > 0.5)) {
      for (const ch of extractRedLetters(line)) cur.redLetters.add(ch);
    }
    // 纯红色行且形如 "ABC" 的，也作为答案
    if (cur && line.redRatio > 0.8 && /^[A-Fa-f、,，\s]+$/.test(t)) {
      for (const ch of extractRedLetters(line)) cur.redLetters.add(ch);
    }
  }
  if (cur) push(cur);

  const questions: ParsedQuestion[] = drafts.map((d) => {
    let answer: string[] = d.explicitAnswer
      .toUpperCase()
      .split("")
      .filter((c) => /^[A-F]$/.test(c));

    if (answer.length === 0 && redAvailable) {
      answer = Array.from(d.redLetters);
    }
    if (answer.length === 0 && redAvailable) {
      answer = d.options.filter((o) => o.red).map((o) => o.key);
    }
    answer = Array.from(new Set(answer)).filter((c) => d.options.some((o) => o.key === c)).sort();

    const errors: string[] = [];
    if (d.stem.replace(/\s/g, "").length < 4) errors.push("题干过短或为空");
    if (d.options.length < 2) errors.push("选项少于 2 个");
    if (d.options.length > 8) errors.push("选项多于 8 个");
    if (answer.length === 0) errors.push(redAvailable ? "未识别到答案（无红字且无『答案：』行）" : "未识别到『答案：』行");
    const dup = d.options.length !== new Set(d.options.map((o) => o.key)).size;
    if (dup) errors.push("存在重复选项编号");

    return {
      num: d.num,
      stem: d.stem.trim(),
      options: d.options.map((o) => ({ ...o, text: o.text.trim() })),
      answer,
      explanation: d.explanation.trim(),
      errors,
    };
  });

  const valid = questions.filter((q) => q.errors.length === 0);
  const invalid = questions.filter((q) => q.errors.length > 0);
  return { questions, valid, invalid, redDetected };
}
