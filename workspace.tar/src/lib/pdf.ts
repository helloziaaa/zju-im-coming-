/* PDF 提取：用 pdf.js 的 operator list 追踪填充颜色，
   把红色文字（标红的答案）与文本内容对齐，输出带红字标记的行。 */
import { getDocument, GlobalWorkerOptions, OPS, Util } from "pdfjs-dist";
// @ts-ignore
import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import type { LineSeg, ParsedLine } from "./parser";

GlobalWorkerOptions.workerSrc = workerUrl;

export interface PdfExtract {
  lines: ParsedLine[];
  pages: number;
  redFound: boolean;
  hasColorPipeline: boolean;
}

interface OpChar {
  ch: string;
  red: boolean;
}

function isRed(c: [number, number, number]): boolean {
  const [r, g, b] = c;
  return r >= 140 && g <= 115 && b <= 115 && r - g >= 60 && r - b >= 60;
}

function normColor(args: unknown[]): [number, number, number] {
  const nums = args.filter((a): a is number => typeof a === "number");
  let [r, g, b] = nums.slice(0, 3);
  if (r === undefined || g === undefined || b === undefined) return [0, 0, 0];
  if (r <= 1 && g <= 1 && b <= 1) {
    r *= 255;
    g *= 255;
    b *= 255;
  }
  return [r, g, b];
}

const isWs = (s: string) => /^\s*$/.test(s);

export async function extractPdf(
  data: ArrayBuffer,
  onPage?: (page: number, total: number) => void,
): Promise<PdfExtract> {
  const task = getDocument({ data: new Uint8Array(data) });
  const doc = await task.promise;
  const total = doc.numPages;
  const lines: ParsedLine[] = [];
  let redFound = false;
  let opCharTotal = 0;

  try {
    for (let p = 1; p <= total; p++) {
      onPage?.(p, total);
      const page = await doc.getPage(p);
      const [tc, ops] = await Promise.all([page.getTextContent(), page.getOperatorList()]);

      // ---- 1. 走 operator list，得到每个字符及颜色 ----
      const opChars: OpChar[] = [];
      let color: [number, number, number] = [0, 0, 0];
      let tlm: number[] = [1, 0, 0, 1, 0, 0];
      let leading = 0;
      const fnArray = ops.fnArray as ArrayLike<number>;
      const argsArray = ops.argsArray as unknown[][];

      for (let i = 0; i < fnArray.length; i++) {
        const fn = fnArray[i];
        const args = argsArray[i] ?? [];
        switch (fn) {
          case OPS.setFillRGBColor:
            color = [args[0] as number, args[1] as number, args[2] as number];
            break;
          case OPS.setFillGray: {
            const g = (args[0] as number) * 255;
            color = [g, g, g];
            break;
          }
          case OPS.setFillColor:
            color = normColor(args);
            break;
          case OPS.setTextMatrix:
            tlm = (args as number[]).slice(0, 6);
            break;
          case OPS.moveText:
            tlm = Util.transform([1, 0, 0, 1, args[0] as number, args[1] as number], tlm);
            break;
          case OPS.setLeadingMoveText:
            leading = -(args[1] as number);
            tlm = Util.transform([1, 0, 0, 1, args[0] as number, args[1] as number], tlm);
            break;
          case OPS.nextLine:
            tlm = Util.transform([1, 0, 0, 1, 0, -leading], tlm);
            break;
          case OPS.showText:
          case OPS.showSpacedText: {
            const raw = args[0];
            let str = "";
            if (typeof raw === "string") str = raw;
            else if (Array.isArray(raw)) str = raw.filter((x): x is string => typeof x === "string").join("");
            if (!str) break;
            const red = isRed(color);
            if (red) redFound = true;
            for (const ch of str) opChars.push({ ch, red });
            break;
          }
          default:
            break;
        }
      }
      opCharTotal += opChars.length;

      // ---- 2. 与 getTextContent 对齐（双指针，容忍空白差异），按 y 分行 ----
      let ptr = 0;
      let prevFlag = false;
      const flagged: { ch: string; red: boolean }[] = [];
      for (const item of tc.items as Array<{ str: string }>) {
        for (const ch of item.str) {
          let guard = 0;
          while (ptr < opChars.length && opChars[ptr].ch !== ch && (isWs(opChars[ptr].ch) || isWs(ch)) && guard < 10) {
            if (isWs(opChars[ptr].ch)) ptr++;
            else break;
            guard++;
          }
          if (ptr < opChars.length && opChars[ptr].ch === ch) {
            prevFlag = opChars[ptr].red;
            ptr++;
          }
          flagged.push({ ch, red: prevFlag });
        }
      }

      let cursor = 0;
      let curY: number | null = null;
      let curSegs: LineSeg[] = [];
      let curText = "";

      const flush = () => {
        if (curText.trim().length > 0) {
          const redChars = curSegs.filter((s) => s.red).reduce((n, s) => n + s.text.length, 0);
          lines.push({
            text: curText.trim(),
            redRatio: curText.trim().length ? redChars / curText.length : 0,
            redText: curSegs.filter((s) => s.red).map((s) => s.text).join(""),
            segs: curSegs,
          });
        }
        curSegs = [];
        curText = "";
      };

      for (const item of tc.items as Array<{ str: string; transform: number[]; height?: number; hasEOL?: boolean }>) {
        const y = item.transform[5];
        const tol = Math.min(8, Math.max(2.5, (item.height ?? 10) * 0.45));
        if (curY !== null && (Math.abs(y - curY) > tol || item.hasEOL)) flush();
        curY = y;
        for (const ch of item.str) {
          const f = flagged[cursor]?.red ?? false;
          cursor++;
          const last = curSegs[curSegs.length - 1];
          if (last && last.red === f) last.text += ch;
          else curSegs.push({ text: ch, red: f });
          curText += ch;
        }
      }
      flush();
      page.cleanup();
    }
  } finally {
    await task.destroy();
  }

  return { lines, pages: total, redFound, hasColorPipeline: opCharTotal > 40 };
}
