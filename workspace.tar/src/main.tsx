import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App.tsx";

const rootEl = document.getElementById("root")!;
const root = ReactDOM.createRoot(rootEl);
root.render(<App />);

/* 标记应用已启动（供 index.html 的加载诊断使用） */
requestAnimationFrame(() => {
  (window as unknown as { __booted?: boolean }).__booted = rootEl.innerHTML.trim() !== "";
});
