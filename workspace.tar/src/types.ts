export interface Option {
  key: string;
  text: string;
}

export interface Question {
  id: string;
  stem: string;
  options: Option[];
  /** 正确选项 key，已排序去重，如 ["A","C"] */
  answer: string[];
  explanation: string;
  source: string;
  createdAt: number;
  sample?: boolean;
  attempts: number;
  correct: number;
  wrongCount: number;
  consecutiveCorrect: number;
  mastered: boolean;
  /** 本轮是否已练过 */
  seenThisCycle: boolean;
  lastAttemptAt?: number;
  lastWrongAt?: number;
}

export type SessionType = "daily" | "weekly" | "review";

export interface SessionRecord {
  id: string;
  type: SessionType;
  order: string[];
  answers: Record<string, string[]>;
  wrongIds: string[];
  correctCount: number;
  total: number;
  accuracy: number;
  finishedAt: number;
  dateKey: string;
}

export interface CycleLog {
  cycle: number;
  at: number;
  accuracy: number;
}

export interface StreakInfo {
  lastDate: string;
  count: number;
  totalDays: number;
}

export interface AppState {
  questions: Question[];
  sessions: SessionRecord[];
  cycle: number;
  cycleStartAt: number;
  cycleHistory: CycleLog[];
  seededSample: boolean;
  streak: StreakInfo;
}

export interface QuizConfig {
  type: SessionType;
  title: string;
  ids: string[];
}
