import { useMemo, useState } from "react";
import { useStore } from "../lib/store";
import type { Question } from "../types";
import type { Tab } from "./Sidebar";
import { Chip, Empty, Modal, Reveal, SectionTitle, cx } from "./ui";
import { IconBank, IconRefresh, IconSearch, IconTrash, IconUpload } from "./icons";

type Filter = "all" | "unseen" | "wrong" | "mastered" | "imported" | "sample";

export function Bank({ goto }: { goto: (t: Tab) => void }) {
  const { state, dispatch } = useStore();
  const [kw, setKw] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [limit, setLimit] = useState(40);
  const [toDelete, setToDelete] = useState<Question | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);

  const list = useMemo(() => {
    let qs = state.questions;
    if (filter === "unseen") qs = qs.filter((q) => q.attempts === 0);
    if (filter === "wrong") qs = qs.filter((q) => q.wrongCount > 0);
    if (filter === "mastered") qs = qs.filter((q) => q.mastered);
    if (filter === "imported") qs = qs.filter((q) => !q.sample);
    if (filter === "sample") qs = qs.filter((q) => q.sample);
    const k = kw.trim().toLowerCase();
    if (k) qs = qs.filter((q) => q.stem.toLowerCase().includes(k) || q.options.some((o) => o.text.toLowerCase().includes(k)));
    return qs;
  }, [state.questions, filter, kw]);

  const filters: { key: Filter; label: string }[] = [
    { key: "all", label: `全部 ${state.questions.length}` },
    { key: "unseen", label: "未练" },
    { key: "wrong", label: "有错题" },
    { key: "mastered", label: "已掌握" },
    { key: "imported", label: "我导入的" },
    { key: "sample", label: "示例题" },
  ];

  const hasSample = state.questions.some((q) => q.sample);

  return (
    <div className="space-y-6">
      <SectionTitle
        no="04"
        title="题库"
        extra={
          <div className="flex gap-2">
            <button
              onClick={() => goto("import")}
              className="btn-press font-display inline-flex items-center gap-1.5 border-2 border-pen-deep bg-pen px-4 py-2 text-sm font-bold text-paper shadow-press"
            >
              <IconUpload className="h-4 w-4" /> 导入 PDF
            </button>
          </div>
        }
      />

      <Reveal>
        <div className="paper-card flex flex-wrap items-center gap-3 p-4">
          <label className="flex min-w-52 flex-1 items-center gap-2 border-2 border-line bg-paper px-3 py-2 focus-within:border-ink">
            <IconSearch className="h-4 w-4 shrink-0 text-ink-faint" />
            <input
              value={kw}
              onChange={(e) => setKw(e.target.value)}
              placeholder="搜索题干或选项…"
              className="w-full bg-transparent text-sm outline-none placeholder:text-ink-faint"
            />
          </label>
          <div className="flex flex-wrap gap-1.5">
            {filters.map((f) => (
              <button
                key={f.key}
                onClick={() => {
                  setFilter(f.key);
                  setLimit(40);
                }}
                className={cx(
                  "border-2 px-3 py-1.5 text-xs font-bold transition-colors",
                  filter === f.key ? "border-ink bg-ink text-paper" : "border-line bg-card text-ink-soft hover:border-ink",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </Reveal>

      {state.questions.length === 0 ? (
        <div className="paper-card">
          <Empty icon={<IconBank className="h-7 w-7" />} title="题库空空如也" desc="导入一份带红色答案的 PDF，或先加载内置示例题库体验。">
            <div className="flex gap-3">
              <button
                onClick={() => dispatch({ type: "LOAD_SAMPLE" })}
                className="btn-press font-display border-2 border-ink bg-card px-5 py-2.5 text-sm font-bold shadow-press"
              >
                加载示例题库（28 题）
              </button>
              <button onClick={() => goto("import")} className="btn-press font-display border-2 border-pen-deep bg-pen px-5 py-2.5 text-sm font-bold text-paper shadow-press">
                导入 PDF
              </button>
            </div>
          </Empty>
        </div>
      ) : (
        <>
          <div className="space-y-3">
            {list.slice(0, limit).map((q, i) => (
              <Reveal key={q.id} delay={Math.min((i % 10) * 35, 280)}>
                <div className="paper-card p-5">
                  <div className="flex items-start gap-3">
                    <span className="font-display mt-0.5 w-8 shrink-0 text-right text-sm font-black text-ink-faint">{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[15px] font-medium leading-relaxed text-ink">{q.stem}</p>
                      <p className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-ink-soft">
                        {q.options.map((o) => (
                          <span key={o.key}>
                            <b className={cx("font-display", q.answer.includes(o.key) ? "text-pen" : "text-ink-faint")}>{o.key}.</b> {o.text}
                          </span>
                        ))}
                      </p>
                      <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-ink-faint">
                        <Chip tone="pen">答案 {q.answer.join("")}</Chip>
                        <Chip tone={q.sample ? "ink" : "blue"}>{q.sample ? "示例" : q.source.slice(0, 14)}</Chip>
                        {q.mastered && <Chip tone="green">已掌握</Chip>}
                        {q.attempts > 0 ? (
                          <span>
                            练 {q.attempts} 次 · 对 {q.correct} 次{q.wrongCount > 0 && <span className="text-pen"> · 错 {q.wrongCount}</span>}
                          </span>
                        ) : (
                          <span>未练</span>
                        )}
                      </p>
                    </div>
                    <div className="flex shrink-0 gap-2">
                      <button
                        onClick={() => dispatch({ type: "RESET_STATS", id: q.id })}
                        className="btn-press border-2 border-line bg-card p-2 text-ink-soft hover:border-amber hover:text-amber"
                        title="清零作答记录"
                      >
                        <IconRefresh className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setToDelete(q)}
                        className="btn-press border-2 border-line bg-card p-2 text-ink-soft hover:border-pen hover:text-pen"
                        title="删除该题"
                      >
                        <IconTrash className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>

          {list.length === 0 && (
            <div className="paper-card">
              <Empty icon={<IconSearch className="h-7 w-7" />} title="没有匹配的题目" desc="换个关键词或筛选条件试试。" />
            </div>
          )}

          {list.length > limit && (
            <div className="text-center">
              <button
                onClick={() => setLimit(limit + 40)}
                className="btn-press border-2 border-ink bg-card px-6 py-2.5 text-sm font-bold shadow-press-sm"
              >
                再显示 40 题（共 {list.length} 题）
              </button>
            </div>
          )}

          <div className="flex flex-wrap justify-between gap-3 border-t-2 border-dashed border-line pt-4 text-xs text-ink-faint">
            <div className="flex gap-2">
              {hasSample && (
                <button onClick={() => dispatch({ type: "CLEAR_SAMPLE" })} className="border border-line px-3 py-1.5 font-bold hover:border-amber hover:text-amber">
                  清空示例题
                </button>
              )}
              {!hasSample && (
                <button onClick={() => dispatch({ type: "LOAD_SAMPLE" })} className="border border-line px-3 py-1.5 font-bold hover:border-ink hover:text-ink">
                  加载示例题
                </button>
              )}
            </div>
            <button onClick={() => setConfirmClear(true)} className="border border-line px-3 py-1.5 font-bold hover:border-pen hover:text-pen">
              清空全部数据
            </button>
          </div>
        </>
      )}

      <Modal
        open={Boolean(toDelete)}
        onClose={() => setToDelete(null)}
        title="删除这道题？"
        footer={
          <>
            <button onClick={() => setToDelete(null)} className="btn-press border-2 border-ink bg-card px-4 py-2 text-sm font-bold shadow-press-sm">
              取消
            </button>
            <button
              onClick={() => {
                if (toDelete) dispatch({ type: "DELETE", id: toDelete.id });
                setToDelete(null);
              }}
              className="btn-press font-display border-2 border-pen bg-pen px-4 py-2 text-sm font-bold text-paper shadow-press-sm"
            >
              删除
            </button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-ink-soft">「{toDelete?.stem.slice(0, 40)}…」将从题库和所有统计中移除，此操作不可撤销。</p>
      </Modal>

      <Modal
        open={confirmClear}
        onClose={() => setConfirmClear(false)}
        title="清空全部数据？"
        footer={
          <>
            <button onClick={() => setConfirmClear(false)} className="btn-press border-2 border-ink bg-card px-4 py-2 text-sm font-bold shadow-press-sm">
              取消
            </button>
            <button
              onClick={() => {
                dispatch({ type: "RESET_ALL" });
                setConfirmClear(false);
              }}
              className="btn-press font-display border-2 border-pen bg-pen px-4 py-2 text-sm font-bold text-paper shadow-press-sm"
            >
              全部清空
            </button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-ink-soft">
          将删除全部 {state.questions.length} 道题目、所有批阅记录与轮次进度。建议先确认不再需要这些数据。
        </p>
      </Modal>
    </div>
  );
}
