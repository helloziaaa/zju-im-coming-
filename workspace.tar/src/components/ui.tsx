import { useEffect, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { IconCross } from "./icons";

export function cx(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

const prefersReduced = () =>
  typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

/* ---------- 滚动显现 ---------- */
export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReduced()) {
      setOn(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setOn(true);
          io.disconnect();
        }
      },
      { threshold: 0.1 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={cx("reveal", on && "reveal-in", className)} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
}

/* ---------- 数字滚动 ---------- */
export function CountUp({
  value,
  decimals = 0,
  duration = 900,
  suffix = "",
  className,
}: {
  value: number;
  decimals?: number;
  duration?: number;
  suffix?: string;
  className?: string;
}) {
  const [v, setV] = useState(0);
  const raf = useRef(0);
  useEffect(() => {
    if (prefersReduced()) {
      setV(value);
      return;
    }
    const start = performance.now();
    const from = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / duration);
      const eased = 1 - Math.pow(1 - p, 3);
      setV(from + (value - from) * eased);
      if (p < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [value, duration]);
  return (
    <span className={className} style={{ fontVariantNumeric: "tabular-nums" }}>
      {v.toFixed(decimals)}
      {suffix}
    </span>
  );
}

/* ---------- 红章 ---------- */
export function Stamp({
  char,
  className,
  tone = "pen",
  style,
}: {
  char: string;
  className?: string;
  tone?: "pen" | "green" | "amber";
  style?: CSSProperties;
}) {
  const color = tone === "green" ? "var(--color-green)" : tone === "amber" ? "var(--color-amber)" : "var(--color-pen)";
  return (
    <div
      className={cx("stamp-in inline-flex items-center justify-center rounded-full select-none", className)}
      style={{
        color,
        border: `3px double ${color}`,
        boxShadow: `inset 0 0 0 2px rgba(255,255,255,0.5), inset 0 0 12px ${color}22`,
        fontFamily: "var(--font-display)",
        fontWeight: 900,
        mixBlendMode: "multiply",
        transform: "rotate(-8deg)",
        ...style,
      }}
    >
      {char}
    </div>
  );
}

/* ---------- 仪表盘 ---------- */
export function Gauge({
  value,
  size = 168,
  stroke = 11,
  target = 0.99,
  label,
  sub,
}: {
  value: number;
  size?: number;
  stroke?: number;
  target?: number | null;
  label: ReactNode;
  sub?: ReactNode;
}) {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const id = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(id);
  }, []);
  const r = (size - stroke) / 2;
  const C = 2 * Math.PI * r;
  const v = Math.min(1, Math.max(0, value));
  const dash = mounted ? C * (1 - v) : C;
  const color = v >= 0.99 ? "var(--color-green)" : v >= 0.75 ? "var(--color-pen)" : "var(--color-amber)";

  // 目标刻度位置（svg 整体 -90° 旋转，参数角 = 占比 × 2π）
  const tAngle = (target ?? 0) * 2 * Math.PI;
  const tx1 = size / 2 + Math.cos(tAngle) * (r - stroke);
  const ty1 = size / 2 + Math.sin(tAngle) * (r - stroke);
  const tx2 = size / 2 + Math.cos(tAngle) * (r + stroke * 0.4);
  const ty2 = size / 2 + Math.sin(tAngle) * (r + stroke * 0.4);

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--color-grid)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="butt"
          strokeDasharray={C}
          strokeDashoffset={dash}
          style={{ transition: prefersReduced() ? "none" : "stroke-dashoffset 1.1s cubic-bezier(0.22,1,0.36,1)" }}
        />
        {target != null && <line x1={tx1} y1={ty1} x2={tx2} y2={ty2} stroke="var(--color-ink)" strokeWidth={2} />}
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
        <div className="leading-none">{label}</div>
        {sub && <div className="mt-1.5 text-xs text-ink-faint">{sub}</div>}
      </div>
    </div>
  );
}

/* ---------- 进度条 ---------- */
export function Bar({ value, tone = "pen", className }: { value: number; tone?: "pen" | "green" | "amber" | "ink"; className?: string }) {
  const color =
    tone === "green" ? "var(--color-green)" : tone === "amber" ? "var(--color-amber)" : tone === "ink" ? "var(--color-inkblue)" : "var(--color-pen)";
  return (
    <div className={cx("h-2 w-full overflow-hidden bg-grid", className)}>
      <div
        className="sweep-in h-full"
        style={{ width: `${Math.min(100, Math.max(0, value * 100))}%`, background: color }}
      />
    </div>
  );
}

/* ---------- 会话类型徽标 ---------- */
export function TypeBadge({ type }: { type: "daily" | "weekly" | "review" }) {
  const map = {
    daily: { text: "每日", cls: "bg-pen-soft text-pen-deep" },
    weekly: { text: "复盘", cls: "bg-inkblue-soft text-inkblue" },
    review: { text: "重练", cls: "bg-amber-soft text-amber" },
  } as const;
  const m = map[type];
  return <span className={cx("px-1.5 py-0.5 text-[11px] font-bold tracking-wider", m.cls)}>{m.text}</span>;
}

/* ---------- 弹窗 ---------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" role="dialog" aria-modal>
      <div className="absolute inset-0 bg-ink/45" onClick={onClose} />
      <div className="fade-up paper-card relative w-full max-w-md">
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
          <h3 className="font-display text-lg font-bold">{title}</h3>
          <button onClick={onClose} className="btn-press p-1 text-ink-soft hover:text-pen" aria-label="关闭">
            <IconCross className="h-4 w-4" />
          </button>
        </div>
        <div className="px-5 py-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-5 py-3.5">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------- 空状态 ---------- */
export function Empty({ icon, title, desc, children }: { icon: ReactNode; title: string; desc?: string; children?: ReactNode }) {
  return (
    <div className="fade-up flex flex-col items-center justify-center px-6 py-16 text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center border-2 border-dashed border-line text-ink-faint">
        {icon}
      </div>
      <p className="font-display text-lg font-bold text-ink">{title}</p>
      {desc && <p className="mt-1.5 max-w-sm text-sm leading-relaxed text-ink-soft">{desc}</p>}
      {children && <div className="mt-5">{children}</div>}
    </div>
  );
}

/* ---------- 小标签 ---------- */
export function Chip({ children, tone = "ink" }: { children: ReactNode; tone?: "ink" | "pen" | "green" | "amber" | "blue" }) {
  const map = {
    ink: "bg-paper-deep text-ink-soft",
    pen: "bg-pen-soft text-pen-deep",
    green: "bg-green-soft text-green",
    amber: "bg-amber-soft text-amber",
    blue: "bg-inkblue-soft text-inkblue",
  } as const;
  return <span className={cx("inline-flex items-center gap-1 px-1.5 py-0.5 text-[11px] font-medium", map[tone])}>{children}</span>;
}

/* ---------- 区块标题 ---------- */
export function SectionTitle({ no, title, extra }: { no: string; title: string; extra?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div className="flex items-baseline gap-2.5">
        <span className="font-display text-sm font-black text-pen">{no}</span>
        <h2 className="font-display text-xl font-black tracking-wide text-ink sm:text-2xl">
          <span className="pen-underline">{title}</span>
        </h2>
      </div>
      {extra}
    </div>
  );
}
