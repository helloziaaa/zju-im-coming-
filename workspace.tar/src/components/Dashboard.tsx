import { dateKey, drawDaily, DAILY_COUNT, useStore } from "../lib/store";
import type { QuizConfig } from "../types";
import type { Tab } from "./Sidebar";
import { Bar, Chip, CountUp, Gauge, Reveal, Stamp, TypeBadge, cx } from "./ui";
import { IconArrow, IconFlame, IconLayers, IconPen, IconTarget, IconUpload } from "./icons";

export function Dashboard({ launch, goto }: { launch: (cfg: QuizConfig) => void; goto: (t: Tab) => void }) {
  const { state, d } = useStore();
  const total = state.questions.length;
  const today = new Date();
  const dateStr = today.toLocaleDateString("zh-CN", { month: "long", day: "numeric", weekday: "long" });
  const hour = today.getHours();
  const greet = hour < 6 ? "夜深了" : hour < 12 ? "早安" : hour < 18 ? "午安" : "晚上好";

  const startDaily = () => {
    const picked = drawDaily(state.questions);
    if (picked.length === 0) return;
    launch({ type: "daily", title: "今日 15 题", ids: picked.map((q) => q.id) });
  };

  const extraSet = () => {
    const picked = drawDaily(state.questions);
    if (picked.length === 0) return;
    launch({ type: "review", title: "加练一组", ids: picked.map((q) => q.id) });
  };

  // 近 7 日
  const days: { label: string; key: string; n: number; isToday: boolean }[] = [];
  for (let i = 6; i >= 0; i--) {
    const t = Date.now() - i * 86400000;
    const key = dateKey(t);
    const wd = new Date(t).toLocaleDateString("zh-CN", { weekday: "short" });
    const n = state.sessions.filter((s) => s.dateKey === key).reduce((sum, s) => sum + s.total, 0);
    days.push({ label: i === 0 ? "今天" : wd, key, n, isToday: i === 0 });
  }
  const maxDay = Math.max(1, ...days.map((x) => x.n));

  const done = d.dailyDone;

  return (
    <div className="space-y-8">
      {/* 开卷 */}
      <header className="ink-rise flex flex-wrap items-end justify-between gap-6">
        <div>
          <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.28em] text-pen">
            <span className="inline-block h-[3px] w-8 bg-pen" />
            DAILY PRACTICE · 不定项选择 · 每题 {DAILY_COUNT} 分制批阅
          </p>
          <h1 className="font-display text-4xl font-black leading-tight text-ink sm:text-5xl">
            {greet}，<span className="pen-underline">{done ? "今日已批阅" : "请完成今日 15 题"}</span>
          </h1>
          <p className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-ink-soft">
            <span>{dateStr}</span>
            <span className="flex items-center gap-1 font-bold text-pen">
              <IconFlame className={cx("h-4 w-4", d.streak.count > 1 && "flame-pulse")} />
              连续 {d.streak.count} 天刷题
            </span>
            <span>
              累计批阅 <b className="font-display text-ink">{d.attempts}</b> 题次
            </span>
          </p>
        </div>
        <div className="hidden items-center gap-4 sm:flex">
          <Stamp
            char={done ? "阅" : "待"}
            className="h-20 w-20 text-3xl"
            tone={done ? "green" : "pen"}
            style={{ animationDelay: "0.25s" }}
          />
          {done && (
            <div className="text-sm">
              <p className="font-display text-2xl font-black text-ink">
                {done.correctCount}/{done.total}
              </p>
              <p className="text-ink-soft">
                正确率 <b className="text-green">{Math.round(done.accuracy * 100)}%</b>
              </p>
            </div>
          )}
        </div>
      </header>

      <div className="grid gap-5 lg:grid-cols-3">
        {/* 今日任务 */}
        <Reveal className="lg:col-span-2">
          <div className="paper-card relative overflow-hidden p-6 sm:p-7">
            <div className="absolute inset-y-0 left-0 w-1.5 bg-pen" />
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="text-[11px] font-bold tracking-[0.24em] text-ink-faint">TODAY'S SET</p>
                <h2 className="font-display mt-1 text-2xl font-black text-ink">今日任务 · 随机 15 题</h2>
                <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-soft">
                  抽题策略：优先<span className="font-bold text-ink">本轮新题</span>，其次
                  <span className="font-bold text-pen">历史错题</span>，穿插已练题目。提交后逐题批阅并附解析。
                </p>
              </div>
              {done && (
                <Stamp char={`${Math.round(done.accuracy * 100)}`} className="h-16 w-16 text-xl" tone={done.accuracy >= 0.9 ? "green" : done.accuracy >= 0.6 ? "amber" : "pen"} />
              )}
            </div>

            {total === 0 ? (
              <div className="mt-6 border-2 border-dashed border-line bg-paper p-6 text-center">
                <p className="font-display text-lg font-bold text-ink">题库还是空的</p>
                <p className="mt-1 text-sm text-ink-soft">上传含红色答案的 PDF，或粘贴文本，立刻开始刷题</p>
                <button
                  onClick={() => goto("import")}
                  className="btn-press font-display mt-4 inline-flex items-center gap-2 border-2 border-ink bg-card px-5 py-2.5 text-sm font-bold text-ink shadow-press"
                >
                  <IconUpload className="h-4 w-4" /> 去导入题目
                </button>
              </div>
            ) : (
              <>
                <div className="mt-5 grid grid-cols-3 gap-3">
                  <div className="border border-line bg-paper px-3 py-2.5">
                    <p className="text-[11px] text-ink-faint">本轮新题</p>
                    <p className="font-display text-xl font-black text-ink">{d.unseenCount}</p>
                  </div>
                  <div className="border border-line bg-paper px-3 py-2.5">
                    <p className="text-[11px] text-ink-faint">待二刷错题</p>
                    <p className="font-display text-xl font-black text-pen">{d.wrongQuestions.length}</p>
                  </div>
                  <div className="border border-line bg-paper px-3 py-2.5">
                    <p className="text-[11px] text-ink-faint">题库总量</p>
                    <p className="font-display text-xl font-black text-ink">{total}</p>
                  </div>
                </div>

                <div className="mt-6 flex flex-wrap items-center gap-3">
                  {!done ? (
                    <button
                      onClick={startDaily}
                      className="btn-press font-display inline-flex items-center gap-2.5 border-2 border-pen-deep bg-pen px-7 py-3.5 text-lg font-black text-paper shadow-press"
                    >
                      <IconPen className="h-5 w-5" /> 开始今日刷题
                      <IconArrow className="h-4 w-4" />
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={extraSet}
                        className="btn-press font-display inline-flex items-center gap-2 border-2 border-ink bg-card px-6 py-3 text-base font-bold text-ink shadow-press"
                      >
                        趁热加练一组 <IconArrow className="h-4 w-4" />
                      </button>
                      <span className="inline-flex items-center gap-1.5 text-sm font-bold text-green">
                        <span className="tick-pop inline-block">✓</span> 今日任务已完成
                      </span>
                    </>
                  )}
                </div>
              </>
            )}
          </div>
        </Reveal>

        {/* 99% 目标 */}
        <Reveal delay={90}>
          <div className="paper-card flex h-full flex-col items-center justify-center p-6 text-center">
            <p className="text-[11px] font-bold tracking-[0.24em] text-ink-faint">GOAL · 99% 正确率</p>
            <div className="my-4">
              <Gauge
                value={d.attempts > 0 ? d.accuracy : 0}
                label={
                  <span className="font-display text-3xl font-black text-ink">
                    <CountUp value={d.accuracy * 100} decimals={1} />%
                  </span>
                }
                sub={`${d.correctCount} / ${d.attempts} 题次`}
              />
            </div>
            {d.goalReached ? (
              <p className="inline-flex items-center gap-1.5 bg-green-soft px-3 py-1.5 text-sm font-bold text-green">
                <IconTarget className="h-4 w-4" /> 已达成 99% 目标！
              </p>
            ) : d.attempts === 0 ? (
              <p className="text-sm text-ink-soft">开始刷题后，这里会追踪你距离 99% 的进度</p>
            ) : (
              <p className="text-sm leading-relaxed text-ink-soft">
                再连续答对 <b className="font-display text-lg text-pen">{d.needCorrect}</b> 题
                <br />
                即可冲上 99% 正确率
              </p>
            )}
          </div>
        </Reveal>

        {/* 轮次进度 */}
        <Reveal>
          <div className="paper-card p-6">
            <div className="mb-3 flex items-center justify-between">
              <p className="flex items-center gap-2 font-display text-base font-black text-ink">
                <IconLayers className="h-4 w-4 text-pen" /> 第 {state.cycle} 轮 · 整库通刷
              </p>
              <Chip tone="blue">{total > 0 ? Math.round((d.cycleSeenCount / total) * 100) : 0}%</Chip>
            </div>
            <Bar value={total > 0 ? d.cycleSeenCount / total : 0} tone="ink" />
            <p className="mt-3 text-[13px] leading-relaxed text-ink-soft">
              已练 <b className="text-ink">{d.cycleSeenCount}</b> / {total} 题。整库刷完一遍后自动进入
              <b className="text-ink">第 {state.cycle + 1} 轮</b>，全部题目重新洗牌再刷，直至正确率 ≥ 99%。
            </p>
            {state.cycleHistory.length > 0 && (
              <div className="mt-3 border-t border-dashed border-line pt-3">
                {state.cycleHistory.slice(-3).map((c) => (
                  <p key={c.cycle} className="text-xs text-ink-faint">
                    第 {c.cycle} 轮完成 · 该组正确率 {Math.round(c.accuracy * 100)}%
                  </p>
                ))}
              </div>
            )}
          </div>
        </Reveal>

        {/* 近 7 日 */}
        <Reveal delay={80}>
          <div className="paper-card p-6">
            <p className="mb-4 font-display text-base font-black text-ink">近 7 日答题量</p>
            <div className="flex h-28 items-end gap-2">
              {days.map((day) => (
                <div key={day.key} className="group flex flex-1 flex-col items-center gap-1.5">
                  <span className="font-display text-[11px] font-bold text-ink-faint opacity-0 transition-opacity group-hover:opacity-100">
                    {day.n}
                  </span>
                  <div
                    className={cx("w-full transition-all duration-300", day.n > 0 ? (day.isToday ? "bg-pen" : "bg-inkblue") : "bg-grid")}
                    style={{ height: `${Math.max(6, (day.n / maxDay) * 88)}px` }}
                    title={`${day.label}：${day.n} 题`}
                  />
                  <span className={cx("text-[11px]", day.isToday ? "font-bold text-pen" : "text-ink-faint")}>{day.label}</span>
                </div>
              ))}
            </div>
          </div>
        </Reveal>

        {/* 最近批阅 */}
        <Reveal delay={140}>
          <div className="paper-card p-6">
            <p className="mb-3 font-display text-base font-black text-ink">最近批阅</p>
            {state.sessions.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink-soft">还没有批阅记录，完成第一组 15 题吧</p>
            ) : (
              <ul className="divide-y divide-dashed divide-line">
                {state.sessions.slice(0, 5).map((s) => (
                  <li key={s.id} className="flex items-center gap-3 py-2.5">
                    <TypeBadge type={s.type} />
                    <span className="flex-1 text-sm text-ink-soft">
                      {s.dateKey.slice(5).replace("-", "/")} · {s.total} 题
                    </span>
                    <span
                      className={cx(
                        "font-display text-base font-black",
                        s.accuracy >= 0.9 ? "text-green" : s.accuracy >= 0.6 ? "text-ink" : "text-pen",
                      )}
                    >
                      {Math.round(s.accuracy * 100)}%
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </Reveal>
      </div>

      {/* 复盘提示条 */}
      {(d.weekWrongIds.length > 0 || d.wrongQuestions.length > 0) && (
        <Reveal>
          <div className="paper-card flex flex-wrap items-center gap-4 border-l-4 border-l-amber p-5">
            <div className="flex-1 text-sm leading-relaxed text-ink-soft">
              <p className="font-display text-base font-black text-ink">本周有 {d.weekWrongIds.length} 道错题等待二刷</p>
              <p className="mt-0.5">
                错题本共 <b className="text-pen">{d.wrongQuestions.length}</b> 道 · 每周复盘是把错题真正吃透的关键一步
              </p>
            </div>
            <button
              onClick={() => goto("weekly")}
              className="btn-press font-display border-2 border-ink bg-amber-soft px-5 py-2.5 text-sm font-bold text-ink shadow-press-sm"
            >
              去每周复盘 <IconArrow className="ml-1 inline h-4 w-4" />
            </button>
          </div>
        </Reveal>
      )}
    </div>
  );
}
