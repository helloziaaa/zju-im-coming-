import { useMemo } from "react";
import { useStore } from "../lib/store";
import type { QuizConfig } from "../types";
import { Chip, Empty, Reveal, SectionTitle, Stamp, cx } from "./ui";
import { IconArrow, IconCalendar, IconCheck, IconClock, IconPen } from "./icons";

export function WeeklyReview({ launch }: { launch: (cfg: QuizConfig) => void }) {
  const { state, d } = useStore();
  const now = Date.now();
  const weekAgo = now - 7 * 86400000;

  const weekSessions = useMemo(() => state.sessions.filter((s) => s.finishedAt >= weekAgo), [state.sessions, weekAgo]);
  const weekAnswered = weekSessions.reduce((n, s) => n + s.total, 0);
  const weekCorrect = weekSessions.reduce((n, s) => n + s.correctCount, 0);
  const weekAcc = weekAnswered > 0 ? weekCorrect / weekAnswered : 0;

  const wrongQs = useMemo(() => {
    const set = new Set(d.weekWrongIds);
    return state.questions.filter((q) => set.has(q.id));
  }, [state.questions, d.weekWrongIds]);

  const start = () => {
    if (wrongQs.length === 0) return;
    launch({ type: "weekly", title: "每周复盘 · 错题二刷", ids: wrongQs.map((q) => q.id) });
  };

  return (
    <div className="space-y-6">
      <SectionTitle no="02" title="每周复盘" extra={<span className="text-xs text-ink-faint">近 7 天 · {new Date(weekAgo).toLocaleDateString("zh-CN", { month: "short", day: "numeric" })} 至今</span>} />

      {/* 本周概览 */}
      <Reveal>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="paper-card p-5">
            <p className="text-[11px] font-bold tracking-[0.22em] text-ink-faint">本周作答</p>
            <p className="font-display mt-1 text-3xl font-black text-ink">{weekAnswered} 题</p>
            <p className="mt-1 text-xs text-ink-soft">{weekSessions.length} 组批阅</p>
          </div>
          <div className="paper-card p-5">
            <p className="text-[11px] font-bold tracking-[0.22em] text-ink-faint">本周正确率</p>
            <p className={cx("font-display mt-1 text-3xl font-black", weekAcc >= 0.9 ? "text-green" : weekAcc >= 0.6 ? "text-ink" : "text-pen")}>
              {weekAnswered > 0 ? `${Math.round(weekAcc * 100)}%` : "—"}
            </p>
            <p className="mt-1 text-xs text-ink-soft">答对 {weekCorrect} 题</p>
          </div>
          <div className="paper-card border-l-4 border-l-pen p-5">
            <p className="text-[11px] font-bold tracking-[0.22em] text-ink-faint">待二刷错题</p>
            <p className="font-display mt-1 text-3xl font-black text-pen">{wrongQs.length} 题</p>
            <p className="mt-1 text-xs text-ink-soft">复盘时优先重练</p>
          </div>
        </div>
      </Reveal>

      {wrongQs.length === 0 ? (
        <Reveal>
          <div className="paper-card relative overflow-hidden">
            <div className="absolute right-6 top-6 opacity-90">
              <Stamp char="赞" tone="green" className="h-20 w-20 text-3xl" />
            </div>
            <Empty
              icon={<IconCalendar className="h-7 w-7" />}
              title="本周还没有错题"
              desc={weekAnswered === 0 ? "本周还没开始刷题，先去完成今日 15 题，错题会自动汇总到这里。" : "本周作答全部正确，保持这个手感！下周一错题会在这里集合。"}
            />
          </div>
        </Reveal>
      ) : (
        <>
          <Reveal>
            <div className="paper-card flex flex-wrap items-center gap-4 p-6">
              <div className="flex-1">
                <h3 className="font-display text-lg font-black text-ink">开始错题二刷（{wrongQs.length} 题）</h3>
                <p className="mt-1 text-sm leading-relaxed text-ink-soft">
                  把本周做错的题重新做一遍。连续答对 2 次的题会标记为「已掌握」，从重点名单里毕业。
                </p>
              </div>
              <button
                onClick={start}
                className="btn-press font-display inline-flex items-center gap-2 border-2 border-pen-deep bg-pen px-6 py-3 text-base font-black text-paper shadow-press"
              >
                <IconPen className="h-5 w-5" /> 开始二刷 <IconArrow className="h-4 w-4" />
              </button>
            </div>
          </Reveal>

          <Reveal delay={80}>
            <div className="paper-card p-5 sm:p-6">
              <p className="mb-4 text-[11px] font-bold tracking-[0.24em] text-ink-faint">错题清单 · MISTAKE LIST</p>
              <ul className="divide-y divide-dashed divide-line">
                {wrongQs.map((q, i) => (
                  <li key={q.id} className="flex items-start gap-3 py-3.5 first:pt-0 last:pb-0">
                    <span className="font-display mt-0.5 w-7 shrink-0 text-right text-sm font-black text-pen">{i + 1}</span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-ink">{q.stem}</p>
                      <p className="mt-1 flex flex-wrap items-center gap-2 text-xs text-ink-faint">
                        <Chip tone="pen">错 {q.wrongCount} 次</Chip>
                        <Chip tone={q.mastered ? "green" : "amber"}>{q.mastered ? "二刷已对" : "待二刷"}</Chip>
                        <span className="inline-flex items-center gap-1">
                          <IconClock className="h-3.5 w-3.5" />
                          {q.lastWrongAt ? new Date(q.lastWrongAt).toLocaleDateString("zh-CN", { month: "short", day: "numeric" }) : ""} 做错
                        </span>
                      </p>
                    </div>
                    <span className="font-display shrink-0 text-sm font-black text-green">{q.answer.join("")}</span>
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>
        </>
      )}

      {weekSessions.length > 0 && (
        <Reveal delay={120}>
          <div className="paper-card p-5 sm:p-6">
            <p className="mb-4 text-[11px] font-bold tracking-[0.24em] text-ink-faint">本周批阅流水</p>
            <ul className="divide-y divide-dashed divide-line">
              {weekSessions.map((s) => (
                <li key={s.id} className="flex items-center gap-3 py-2.5 text-sm">
                  <span className="text-ink-faint">{s.dateKey.slice(5).replace("-", "/")}</span>
                  <span className="text-ink-soft">
                    {s.type === "daily" ? "每日 15 题" : s.type === "weekly" ? "错题二刷" : "自主加练"}
                  </span>
                  <span className="ml-auto flex items-center gap-2">
                    <span className={cx("font-display font-black", s.accuracy >= 0.9 ? "text-green" : s.accuracy >= 0.6 ? "text-ink" : "text-pen")}>
                      {Math.round(s.accuracy * 100)}%
                    </span>
                    {s.wrongIds.length === 0 ? (
                      <span className="inline-flex items-center gap-1 text-green">
                        <IconCheck className="h-3.5 w-3.5" /> 全对
                      </span>
                    ) : (
                      <span className="text-xs text-pen">错 {s.wrongIds.length}</span>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      )}
    </div>
  );
}
