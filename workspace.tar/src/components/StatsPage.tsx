import { useMemo } from "react";
import { GOAL_ACCURACY, useStore } from "../lib/store";
import { Bar, Chip, CountUp, Empty, Gauge, Reveal, SectionTitle, cx } from "./ui";
import { IconChart, IconLayers } from "./icons";

export function StatsPage() {
  const { state, d } = useStore();
  const total = state.questions.length;

  const trend = useMemo(() => [...state.sessions].slice(0, 24).reverse(), [state.sessions]);
  const neverTried = state.questions.filter((q) => q.attempts === 0).length;
  const mastered = d.masteredCount;
  const learning = total - neverTried - mastered;

  // 趋势图坐标
  const W = 640;
  const H = 210;
  const PAD = { l: 34, r: 14, t: 14, b: 26 };
  const pts = trend.map((s, i) => {
    const x = trend.length === 1 ? (W - PAD.l - PAD.r) / 2 + PAD.l : PAD.l + (i / (trend.length - 1)) * (W - PAD.l - PAD.r);
    const y = PAD.t + (1 - s.accuracy) * (H - PAD.t - PAD.b);
    return { x, y, s };
  });
  const goalY = PAD.t + (1 - GOAL_ACCURACY) * (H - PAD.t - PAD.b);
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(" ");

  return (
    <div className="space-y-6">
      <SectionTitle no="05" title="数据统计" extra={<span className="text-xs text-ink-faint">所有批阅记录自动汇总</span>} />

      {/* KPI */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: "累计作答", v: <CountUp value={d.attempts} />, unit: "题次", tone: "text-ink" },
          { label: "总正确率", v: <CountUp value={d.accuracy * 100} decimals={1} />, unit: "%", tone: d.accuracy >= 0.99 ? "text-green" : "text-pen" },
          { label: "累计刷题天数", v: <CountUp value={d.streak.totalDays} />, unit: "天", tone: "text-ink" },
          { label: "当前轮次", v: <CountUp value={state.cycle} />, unit: `第 / 共${state.cycleHistory.length + 1}轮在途`, tone: "text-inkblue" },
        ].map((k, i) => (
          <Reveal key={k.label} delay={i * 60}>
            <div className="paper-card p-5">
              <p className="text-[11px] font-bold tracking-[0.2em] text-ink-faint">{k.label}</p>
              <p className={cx("font-display mt-1.5 text-3xl font-black sm:text-4xl", k.tone)}>
                {k.v}
                <span className="ml-1 text-xs font-bold text-ink-faint">{k.unit}</span>
              </p>
            </div>
          </Reveal>
        ))}
      </div>

      {state.sessions.length === 0 ? (
        <Reveal>
          <div className="paper-card">
            <Empty icon={<IconChart className="h-7 w-7" />} title="还没有数据" desc="完成一组刷题后，这里会出现正确率趋势、掌握度分布和轮次记录。" />
          </div>
        </Reveal>
      ) : (
        <div className="grid gap-5 lg:grid-cols-5">
          {/* 趋势 */}
          <Reveal className="lg:col-span-3">
            <div className="paper-card p-5 sm:p-6">
              <div className="mb-4 flex items-center justify-between">
                <p className="font-display text-base font-black text-ink">正确率趋势 · 最近 {trend.length} 组</p>
                <Chip tone="pen">目标线 99%</Chip>
              </div>
              <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
                {/* 网格 */}
                {[0, 0.25, 0.5, 0.75, 1].map((g) => {
                  const y = PAD.t + (1 - g) * (H - PAD.t - PAD.b);
                  return (
                    <g key={g}>
                      <line x1={PAD.l} y1={y} x2={W - PAD.r} y2={y} stroke="var(--color-grid)" strokeWidth="1" />
                      <text x={PAD.l - 6} y={y + 3.5} textAnchor="end" fontSize="10" fill="var(--color-ink-faint)">
                        {g * 100}
                      </text>
                    </g>
                  );
                })}
                {/* 99% 目标线 */}
                <line x1={PAD.l} y1={goalY} x2={W - PAD.r} y2={goalY} stroke="var(--color-pen)" strokeWidth="1.6" strokeDasharray="6 4" />
                <text x={W - PAD.r} y={goalY - 5} textAnchor="end" fontSize="10" fontWeight="700" fill="var(--color-pen)">
                  99% 目标
                </text>
                {/* 曲线 */}
                {pts.length > 1 && <path d={path} fill="none" stroke="var(--color-inkblue)" strokeWidth="2.2" />}
                {pts.map((p) => (
                  <g key={p.s.id}>
                    <circle cx={p.x} cy={p.y} r="4.2" fill={p.s.accuracy >= 0.9 ? "var(--color-green)" : p.s.accuracy >= 0.6 ? "var(--color-inkblue)" : "var(--color-pen)"} />
                    <title>{`${p.s.dateKey} · ${p.s.total}题 · 正确率 ${Math.round(p.s.accuracy * 100)}%`}</title>
                  </g>
                ))}
              </svg>
            </div>
          </Reveal>

          {/* 掌握度 + 目标 */}
          <Reveal delay={90} className="lg:col-span-2">
            <div className="paper-card flex h-full flex-col p-5 sm:p-6">
              <p className="font-display mb-4 text-base font-black text-ink">题库掌握度</p>
              <div className="flex items-center justify-center">
                <Gauge
                  size={150}
                  value={total > 0 ? mastered / total : 0}
                  target={null}
                  label={
                    <span className="font-display text-2xl font-black text-ink">
                      <CountUp value={total > 0 ? (mastered / total) * 100 : 0} decimals={0} />%
                    </span>
                  }
                  sub="已掌握占比"
                />
              </div>
              <div className="mt-4 space-y-2.5 text-sm">
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 bg-green" /> 已掌握（连对 2 次）
                  <b className="font-display ml-auto">{mastered}</b>
                </div>
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 bg-inkblue" /> 练习中
                  <b className="font-display ml-auto">{learning}</b>
                </div>
                <div className="flex items-center gap-2">
                  <span className="h-3 w-3 bg-grid" /> 从未练过
                  <b className="font-display ml-auto">{neverTried}</b>
                </div>
                <div className="pt-2">
                  <Bar value={total > 0 ? mastered / total : 0} tone="green" />
                </div>
              </div>
            </div>
          </Reveal>

          {/* 轮次记录 */}
          <Reveal className="lg:col-span-3">
            <div className="paper-card p-5 sm:p-6">
              <p className="font-display mb-4 flex items-center gap-2 text-base font-black text-ink">
                <IconLayers className="h-4 w-4 text-pen" /> 轮次记录
              </p>
              {state.cycleHistory.length === 0 ? (
                <p className="py-4 text-sm text-ink-soft">
                  第 1 轮进行中：已练 {d.cycleSeenCount} / {total} 题。整库练完一遍后自动记录本轮并重新洗牌。
                </p>
              ) : (
                <ul className="divide-y divide-dashed divide-line">
                  {state.cycleHistory.map((c) => (
                    <li key={c.cycle} className="flex items-center gap-3 py-2.5 text-sm">
                      <span className="font-display font-black text-ink">第 {c.cycle} 轮</span>
                      <span className="text-ink-faint">{new Date(c.at).toLocaleDateString("zh-CN")}</span>
                      <span className="ml-auto text-ink-soft">收官组正确率</span>
                      <b className={cx("font-display", c.accuracy >= 0.99 ? "text-green" : "text-pen")}>{Math.round(c.accuracy * 100)}%</b>
                    </li>
                  ))}
                  <li className="flex items-center gap-3 py-2.5 text-sm">
                    <span className="font-display font-black text-pen">第 {state.cycle} 轮</span>
                    <Chip tone="blue">进行中</Chip>
                    <span className="ml-auto text-ink-soft">
                      进度 {d.cycleSeenCount}/{total}
                    </span>
                  </li>
                </ul>
              )}
            </div>
          </Reveal>

          {/* 题型构成 */}
          <Reveal delay={90} className="lg:col-span-2">
            <div className="paper-card p-5 sm:p-6">
              <p className="font-display mb-4 text-base font-black text-ink">批阅构成</p>
              {(
                [
                  ["daily", "每日 15 题"],
                  ["weekly", "错题二刷"],
                  ["review", "自主加练"],
                ] as const
              ).map(([t, label]) => {
                const n = state.sessions.filter((s) => s.type === t).length;
                const acc = (() => {
                  const ss = state.sessions.filter((s) => s.type === t);
                  const tot = ss.reduce((a, s) => a + s.total, 0);
                  const cor = ss.reduce((a, s) => a + s.correctCount, 0);
                  return tot > 0 ? Math.round((cor / tot) * 100) : null;
                })();
                return (
                  <div key={t} className="mb-3 last:mb-0">
                    <div className="mb-1 flex items-center justify-between text-sm">
                      <span className="text-ink-soft">{label}</span>
                      <span className="font-display font-black text-ink">
                        {n} 组{acc != null && <span className="ml-2 text-ink-faint">{acc}%</span>}
                      </span>
                    </div>
                    <Bar value={state.sessions.length > 0 ? n / state.sessions.length : 0} tone={t === "daily" ? "pen" : t === "weekly" ? "ink" : "amber"} />
                  </div>
                );
              })}
              <p className="mt-4 border-t border-dashed border-line pt-3 text-xs leading-relaxed text-ink-faint">
                当前累计正确率 <b className="text-pen">{(d.accuracy * 100).toFixed(1)}%</b>
                {d.goalReached ? "，已达成 99% 目标！" : `，距离 99% 目标还需约 ${d.needCorrect} 次连续答对。`}
              </p>
            </div>
          </Reveal>
        </div>
      )}
    </div>
  );
}
