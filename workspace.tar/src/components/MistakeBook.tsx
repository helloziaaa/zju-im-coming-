import { useMemo, useState } from "react";
import { drawMistakes, useStore } from "../lib/store";
import type { Question, QuizConfig } from "../types";
import { Chip, Empty, Modal, Reveal, SectionTitle, cx } from "./ui";
import { IconArrow, IconNotebook, IconPen, IconRefresh, IconTrash } from "./icons";

type Filter = "all" | "once" | "multi";

export function MistakeBook({ launch }: { launch: (cfg: QuizConfig) => void }) {
  const { state, d, dispatch } = useStore();
  const [filter, setFilter] = useState<Filter>("all");
  const [confirmReset, setConfirmReset] = useState<Question | null>(null);

  const wrongs = d.wrongQuestions;
  const list = useMemo(() => {
    if (filter === "once") return wrongs.filter((q) => q.wrongCount === 1);
    if (filter === "multi") return wrongs.filter((q) => q.wrongCount >= 2);
    return wrongs;
  }, [wrongs, filter]);

  const practice = () => {
    const picked = drawMistakes(state.questions);
    if (picked.length === 0) return;
    launch({ type: "review", title: "错题重练", ids: picked.map((q) => q.id) });
  };

  const practiceOne = (q: Question) => launch({ type: "review", title: "单题重练", ids: [q.id] });

  const filters: { key: Filter; label: string; n: number }[] = [
    { key: "all", label: "全部", n: wrongs.length },
    { key: "once", label: "错 1 次", n: wrongs.filter((q) => q.wrongCount === 1).length },
    { key: "multi", label: "错 ≥2 次", n: wrongs.filter((q) => q.wrongCount >= 2).length },
  ];

  return (
    <div className="space-y-6">
      <SectionTitle no="03" title="错题本" extra={<span className="text-xs text-ink-faint">做错的题都在这里，直到刷对为止</span>} />

      <Reveal>
        <div className="paper-card flex flex-wrap items-center gap-4 border-l-4 border-l-pen p-6">
          <div className="flex-1">
            <h3 className="font-display text-lg font-black text-ink">
              错题本共 <span className="text-pen">{wrongs.length}</span> 道
            </h3>
            <p className="mt-1 text-sm text-ink-soft">重练按「错得越多越靠前」抽取，最多 15 题一组。连续答对 2 次即标记掌握。</p>
          </div>
          <button
            onClick={practice}
            disabled={wrongs.length === 0}
            className="btn-press font-display inline-flex items-center gap-2 border-2 border-pen-deep bg-pen px-6 py-3 text-base font-black text-paper shadow-press disabled:cursor-not-allowed disabled:opacity-40"
          >
            <IconPen className="h-5 w-5" /> 错题重练 <IconArrow className="h-4 w-4" />
          </button>
        </div>
      </Reveal>

      {wrongs.length === 0 ? (
        <Reveal>
          <div className="paper-card">
            <Empty
              icon={<IconNotebook className="h-7 w-7" />}
              title="错题本是空的"
              desc="太干净了！继续刷题，做错的题会自动收进来；答对两次就会被移出去。"
            />
          </div>
        </Reveal>
      ) : (
        <>
          <div className="flex gap-2">
            {filters.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={cx(
                  "btn-press border-2 px-4 py-1.5 text-sm font-bold transition-colors",
                  filter === f.key ? "border-ink bg-ink text-paper shadow-press-sm" : "border-line bg-card text-ink-soft hover:border-ink",
                )}
              >
                {f.label} <span className="font-display">{f.n}</span>
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {list.map((q, i) => (
              <Reveal key={q.id} delay={Math.min(i * 40, 300)}>
                <div className="paper-card p-5 transition-transform duration-200 hover:-translate-y-0.5">
                  <div className="flex items-start gap-4">
                    <span
                      className={cx(
                        "font-display flex h-10 w-10 shrink-0 flex-col items-center justify-center border-2 leading-none",
                        q.wrongCount >= 2 ? "border-pen bg-pen text-paper" : "border-pen bg-pen-soft text-pen",
                      )}
                    >
                      <span className="text-[10px]">错</span>
                      <span className="text-base font-black">{q.wrongCount}</span>
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-[15px] font-medium leading-relaxed text-ink">{q.stem}</p>
                      <p className="mt-2 flex flex-wrap items-center gap-2 text-xs text-ink-faint">
                        <Chip tone="green">答案 {q.answer.join("")}</Chip>
                        <Chip tone="blue">{q.options.length} 个选项</Chip>
                        <Chip tone={q.mastered ? "green" : "amber"}>{q.mastered ? "已掌握" : "未掌握"}</Chip>
                        <span>
                          练 {q.attempts} 次 · 对 {q.correct} 次
                        </span>
                      </p>
                    </div>
                    <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
                      <button
                        onClick={() => practiceOne(q)}
                        className="btn-press border-2 border-ink bg-card px-3 py-1.5 text-xs font-bold shadow-press-sm"
                      >
                        重练这题
                      </button>
                      <button
                        onClick={() => setConfirmReset(q)}
                        className="btn-press inline-flex items-center gap-1 border-2 border-line bg-card px-3 py-1.5 text-xs font-bold text-ink-soft hover:border-amber hover:text-amber"
                        title="清零该题的作答记录，从错题本移出"
                      >
                        <IconRefresh className="h-3.5 w-3.5" /> 清零
                      </button>
                      <button
                        onClick={() => dispatch({ type: "DELETE", id: q.id })}
                        className="btn-press inline-flex items-center gap-1 border-2 border-line bg-card px-3 py-1.5 text-xs font-bold text-ink-soft hover:border-pen hover:text-pen"
                      >
                        <IconTrash className="h-3.5 w-3.5" /> 删除
                      </button>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </>
      )}

      <Modal
        open={Boolean(confirmReset)}
        onClose={() => setConfirmReset(null)}
        title="清零该题记录？"
        footer={
          <>
            <button onClick={() => setConfirmReset(null)} className="btn-press border-2 border-ink bg-card px-4 py-2 text-sm font-bold shadow-press-sm">
              取消
            </button>
            <button
              onClick={() => {
                if (confirmReset) dispatch({ type: "RESET_STATS", id: confirmReset.id });
                setConfirmReset(null);
              }}
              className="btn-press font-display border-2 border-amber bg-amber-soft px-4 py-2 text-sm font-bold text-amber shadow-press-sm"
            >
              确认清零
            </button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-ink-soft">
          「{confirmReset?.stem.slice(0, 30)}…」的作答记录（{confirmReset?.attempts} 次作答、{confirmReset?.wrongCount} 次错误）将被清零，
          该题会重新变回「本轮未练」状态。
        </p>
      </Modal>
    </div>
  );
}
