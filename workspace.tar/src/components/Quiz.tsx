import { useEffect, useMemo, useState } from "react";
import { isCorrect, useStore } from "../lib/store";
import type { Question, QuizConfig, SessionRecord } from "../types";
import { Bar, Chip, Modal, Stamp, TypeBadge, cx } from "./ui";
import { IconArrow, IconCheck, IconCross } from "./icons";

export function Quiz({ cfg, onExit, onAgain }: { cfg: QuizConfig; onExit: () => void; onAgain?: () => void }) {
  const { state, recordSession } = useStore();
  const questions = useMemo(
    () => cfg.ids.map((id) => state.questions.find((q) => q.id === id)).filter((q): q is Question => Boolean(q)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [cfg],
  );

  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [phase, setPhase] = useState<"answer" | "result">("answer");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [result, setResult] = useState<SessionRecord | null>(null);
  const [expOpen, setExpOpen] = useState<Record<string, boolean>>({});

  const q = questions[idx];
  const answeredCount = questions.filter((x) => (answers[x.id] ?? []).length > 0).length;

  const toggle = (qid: string, key: string) => {
    setAnswers((prev) => {
      const cur = prev[qid] ?? [];
      const next = cur.includes(key) ? cur.filter((k) => k !== key) : [...cur, key].sort();
      return { ...prev, [qid]: next };
    });
  };

  const finalize = () => {
    const s = recordSession(cfg.type, questions.map((x) => x.id), answers);
    setResult(s);
    setPhase("result");
    window.scrollTo({ top: 0 });
  };

  const trySubmit = () => {
    if (answeredCount < questions.length) setConfirmOpen(true);
    else finalize();
  };

  // 快捷键
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (phase !== "answer" || !q) return;
      const t = e.target as HTMLElement | null;
      if (t && ["BUTTON", "INPUT", "TEXTAREA"].includes(t.tagName)) return;
      const k = e.key.toUpperCase();
      if (/^[A-F]$/.test(k) && q.options.some((o) => o.key === k)) {
        toggle(q.id, k);
      } else if (e.key === "ArrowRight" || e.key === "Enter") {
        if (idx < questions.length - 1) setIdx(idx + 1);
      } else if (e.key === "ArrowLeft") {
        if (idx > 0) setIdx(idx - 1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, q, idx, questions.length]);

  if (questions.length === 0) {
    return (
      <div className="paper-card p-10 text-center">
        <p className="font-display text-lg font-bold">题目不存在或已被删除</p>
        <button onClick={onExit} className="btn-press font-display mt-4 border-2 border-ink bg-card px-5 py-2 font-bold shadow-press-sm">
          返回
        </button>
      </div>
    );
  }

  /* ---------------- 批阅结果页 ---------------- */
  if (phase === "result" && result && q) {
    const acc = result.accuracy;
    const grade = acc >= 0.9 ? "优" : acc >= 0.75 ? "良" : acc >= 0.6 ? "及" : "再练";
    const tone = acc >= 0.9 ? "green" : acc >= 0.6 ? ("amber" as const) : ("pen" as const);
    return (
      <div className="space-y-6">
        <header className="ink-rise paper-card relative overflow-hidden p-6 sm:p-8">
          <div className="absolute inset-y-0 left-0 w-1.5 bg-pen" />
          <div className="flex flex-wrap items-center gap-6">
            <Stamp char={grade} className="h-24 w-24 text-4xl" tone={tone} />
            <div>
              <p className="flex items-center gap-2 text-[11px] font-bold tracking-[0.24em] text-ink-faint">
                <TypeBadge type={result.type} /> 批阅完成 · {result.dateKey.slice(5).replace("-", "/")}
              </p>
              <p className="font-display mt-1 text-5xl font-black text-ink">
                {result.correctCount}
                <span className="text-2xl text-ink-faint"> / {result.total}</span>
              </p>
              <p className="mt-1 text-sm text-ink-soft">
                正确率{" "}
                <b className={cx("font-display text-lg", tone === "green" ? "text-green" : tone === "amber" ? "text-amber" : "text-pen")}>
                  {Math.round(acc * 100)}%
                </b>
                · 错 {result.wrongIds.length} 题已自动记入错题本，等待每周二刷
              </p>
            </div>
            <div className="ml-auto flex flex-col gap-2">
              <button onClick={onExit} className="btn-press font-display border-2 border-pen-deep bg-pen px-5 py-2.5 text-sm font-bold text-paper shadow-press">
                返回总览
              </button>
              {onAgain && (
                <button onClick={onAgain} className="btn-press font-display border-2 border-ink bg-card px-5 py-2.5 text-sm font-bold text-ink shadow-press-sm">
                  再来一组
                </button>
              )}
            </div>
          </div>
        </header>

        <div className="space-y-4">
          {questions.map((x, i) => {
            const sel = answers[x.id] ?? [];
            const ok = isCorrect(x, sel);
            const showExp = expOpen[x.id] ?? !ok;
            return (
              <article
                key={x.id}
                className="ink-rise paper-card p-5 sm:p-6"
                style={{ animationDelay: `${Math.min(i * 70, 700)}ms` }}
              >
                <div className="flex items-start gap-4">
                  <span
                    className={cx(
                      "mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center border-2",
                      ok ? "border-green bg-green-soft text-green" : "border-pen bg-pen-soft text-pen",
                    )}
                  >
                    {ok ? <IconCheck className="h-4 w-4" /> : <IconCross className="h-4 w-4" />}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-display text-[15px] font-bold leading-relaxed text-ink">
                      <span className="mr-2 text-pen">{i + 1}.</span>
                      {x.stem}
                    </p>

                    <div className="mt-3 grid gap-2 sm:grid-cols-2">
                      {x.options.map((o) => {
                        const isAns = x.answer.includes(o.key);
                        const isSel = sel.includes(o.key);
                        return (
                          <div
                            key={o.key}
                            className={cx(
                              "flex items-start gap-2.5 border px-3 py-2 text-sm",
                              isAns && "border-green bg-green-soft/60",
                              isSel && !isAns && "border-pen bg-pen-soft/60",
                              !isAns && !isSel && "border-line bg-paper",
                            )}
                          >
                            <span
                              className={cx(
                                "font-display mt-px flex h-5 w-5 shrink-0 items-center justify-center text-xs font-black",
                                isAns ? "bg-green text-paper" : isSel ? "bg-pen text-paper" : "bg-grid text-ink-soft",
                              )}
                            >
                              {o.key}
                            </span>
                            <span className="flex-1 leading-relaxed text-ink">{o.text}</span>
                            {isAns && <IconCheck className="mt-0.5 h-4 w-4 shrink-0 text-green" />}
                            {isSel && !isAns && <IconCross className="mt-0.5 h-4 w-4 shrink-0 text-pen" />}
                          </div>
                        );
                      })}
                    </div>

                    <p className="mt-3 text-[13px] text-ink-soft">
                      你的答案：
                      <b className={cx("font-display text-base", ok ? "text-green" : "text-pen")}>{sel.length ? sel.join(" ") : "未作答"}</b>
                      <span className="mx-2 text-line">|</span>
                      正确答案：<b className="font-display text-base text-green">{x.answer.join(" ")}</b>
                    </p>

                    <div className="mt-3 border-l-2 border-pen bg-paper px-4 py-3">
                      <button
                        className="flex w-full items-center justify-between text-left"
                        onClick={() => setExpOpen((p) => ({ ...p, [x.id]: !showExp }))}
                      >
                        <span className="text-[11px] font-bold tracking-[0.22em] text-pen">解析 · EXPLANATION</span>
                        <span className="text-xs text-ink-faint">{showExp ? "收起" : "展开"}</span>
                      </button>
                      {showExp && (
                        <p className="fade-up mt-2 text-sm leading-relaxed text-ink-soft">
                          {x.explanation || "该题暂无解析。"}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </div>
    );
  }

  /* ---------------- 作答页 ---------------- */
  const sel = answers[q.id] ?? [];
  return (
    <div className="space-y-5">
      <header className="ink-rise paper-card flex flex-wrap items-center gap-4 p-4 sm:p-5">
        <button onClick={onExit} className="btn-press border-2 border-ink bg-card px-3 py-1.5 text-sm font-bold shadow-press-sm">
          ← 退出
        </button>
        <div className="min-w-0">
          <p className="flex items-center gap-2">
            <TypeBadge type={cfg.type} />
            <span className="font-display truncate text-lg font-black text-ink">{cfg.title}</span>
          </p>
          <p className="text-xs text-ink-faint">不定项选择 · 少选、多选、错选均不得分</p>
        </div>
        <div className="ml-auto text-right">
          <p className="font-display text-2xl font-black text-ink">
            {idx + 1}
            <span className="text-sm text-ink-faint"> / {questions.length}</span>
          </p>
        </div>
      </header>

      <Bar value={(idx + 1) / questions.length} className="h-1.5" />

      <div className="grid gap-5 lg:grid-cols-[1fr_230px]">
        {/* 题目卡 */}
        <article key={q.id} className="ink-rise paper-card p-6 sm:p-8">
          <div className="mb-4 flex items-center gap-2">
            <Chip tone="pen">不定项</Chip>
            <Chip tone={sel.length > 0 ? "blue" : "ink"}>已选 {sel.length} 项</Chip>
            <span className="ml-auto font-display text-sm font-black text-pen">第 {idx + 1} 题</span>
          </div>
          <h2 className="font-display text-xl font-bold leading-relaxed text-ink sm:text-[22px]">{q.stem}</h2>

          <div className="mt-6 space-y-3">
            {q.options.map((o) => {
              const on = sel.includes(o.key);
              return (
                <button
                  key={o.key}
                  onClick={() => toggle(q.id, o.key)}
                  className={cx(
                    "opt-sweep btn-press flex w-full items-start gap-3.5 border-2 px-4 py-3.5 text-left",
                    on ? "is-on border-pen shadow-press-sm" : "border-line bg-card hover:border-ink",
                  )}
                  style={{ "--fill": "var(--color-pen-soft)" } as React.CSSProperties}
                >
                  <span
                    className={cx(
                      "font-display flex h-7 w-7 shrink-0 items-center justify-center border-2 text-sm font-black transition-colors",
                      on ? "border-pen bg-pen text-paper" : "border-ink-soft bg-paper text-ink-soft",
                    )}
                  >
                    {o.key}
                  </span>
                  <span className={cx("flex-1 pt-0.5 text-[15px] leading-relaxed", on ? "font-bold text-ink" : "text-ink")}>{o.text}</span>
                  <span
                    className={cx(
                      "mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border-2 transition-all",
                      on ? "tick-pop border-pen bg-pen text-paper" : "border-line bg-paper text-transparent",
                    )}
                  >
                    <IconCheck className="h-3 w-3" />
                  </span>
                </button>
              );
            })}
          </div>

          <div className="mt-7 flex items-center justify-between">
            <button
              onClick={() => setIdx(Math.max(0, idx - 1))}
              disabled={idx === 0}
              className="btn-press border-2 border-line bg-card px-5 py-2.5 text-sm font-bold text-ink-soft shadow-press-sm disabled:cursor-not-allowed disabled:opacity-40"
            >
              ← 上一题
            </button>
            {idx < questions.length - 1 ? (
              <button
                onClick={() => setIdx(idx + 1)}
                className="btn-press font-display inline-flex items-center gap-2 border-2 border-ink bg-card px-6 py-2.5 text-sm font-bold text-ink shadow-press"
              >
                下一题 <IconArrow className="h-4 w-4" />
              </button>
            ) : (
              <button
                onClick={trySubmit}
                className="btn-press font-display border-2 border-pen-deep bg-pen px-6 py-2.5 text-sm font-black text-paper shadow-press"
              >
                提交批阅 ✓
              </button>
            )}
          </div>
        </article>

        {/* 答题卡 */}
        <aside className="lg:sticky lg:top-6 lg:self-start">
          <div className="paper-card p-5">
            <p className="mb-3 flex items-center justify-between text-xs font-bold tracking-widest text-ink-faint">
              答题卡 <span className="text-ink">{answeredCount}/{questions.length}</span>
            </p>
            <div className="grid grid-cols-5 gap-1.5">
              {questions.map((x, i) => {
                const done = (answers[x.id] ?? []).length > 0;
                return (
                  <button
                    key={x.id}
                    onClick={() => setIdx(i)}
                    className={cx(
                      "font-display flex h-9 items-center justify-center border text-sm font-bold transition-all",
                      i === idx ? "border-pen text-pen ring-2 ring-pen/30" : done ? "border-pen bg-pen text-paper" : "border-line bg-paper text-ink-faint hover:border-ink",
                    )}
                  >
                    {i + 1}
                  </button>
                );
              })}
            </div>
            <button
              onClick={trySubmit}
              className="btn-press font-display mt-5 w-full border-2 border-pen-deep bg-pen py-3 text-sm font-black text-paper shadow-press"
            >
              提交批阅
            </button>
            <p className="mt-3 text-center text-[11px] leading-relaxed text-ink-faint">
              键盘 A–F 选择 · ←→ 切题
              <br />
              Enter 下一题
            </p>
          </div>
        </aside>
      </div>

      <Modal
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        title="还有未作答的题目"
        footer={
          <>
            <button onClick={() => setConfirmOpen(false)} className="btn-press border-2 border-ink bg-card px-4 py-2 text-sm font-bold shadow-press-sm">
              继续作答
            </button>
            <button
              onClick={() => {
                setConfirmOpen(false);
                finalize();
              }}
              className="btn-press font-display border-2 border-pen-deep bg-pen px-4 py-2 text-sm font-bold text-paper shadow-press"
            >
              直接提交
            </button>
          </>
        }
      >
        <p className="text-sm leading-relaxed text-ink-soft">
          还有 <b className="font-display text-lg text-pen">{questions.length - answeredCount}</b> 题未作答，未作答按错题处理。确定要现在提交批阅吗？
        </p>
      </Modal>
    </div>
  );
}
