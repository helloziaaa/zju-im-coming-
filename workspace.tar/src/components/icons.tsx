/* 自绘线性图标：方头笔触，呼应印刷/批阅质感 */
interface P {
  className?: string;
}

const base = (className?: string) => ({
  className,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "square" as const,
  strokeLinejoin: "miter" as const,
});

export const IconHome = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4 11.5 12 4l8 7.5" />
    <path d="M6 10.5V20h12v-9.5" />
    <path d="M10 20v-5h4v5" />
  </svg>
);

export const IconTarget = ({ className }: P) => (
  <svg {...base(className)}>
    <circle cx="12" cy="12" r="8" />
    <circle cx="12" cy="12" r="3.5" />
    <path d="M12 2v3M12 19v3M2 12h3M19 12h3" />
  </svg>
);

export const IconCalendar = ({ className }: P) => (
  <svg {...base(className)}>
    <rect x="3.5" y="5" width="17" height="15.5" />
    <path d="M3.5 9.5h17M8 2.8V6.5M16 2.8V6.5" />
    <path d="M7.5 13.5h3M13.5 13.5h3M7.5 17h3" />
  </svg>
);

export const IconNotebook = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M6 3.5h13.5V21H6a2 2 0 0 1-2-2V5.5a2 2 0 0 1 2-2Z" />
    <path d="M8.5 3.5v17.5" />
    <path d="M12 9l5 5M17 9l-5 5" />
  </svg>
);

export const IconBank = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4 20.5h16" />
    <path d="M5.5 20.5V9.5h3v11M10.5 20.5V5h3v15.5M15.5 20.5V12h3v8.5" />
  </svg>
);

export const IconChart = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M3.5 3.5v17h17" />
    <path d="M7.5 15.5l3.5-4 3 2.5 4.5-6.5" />
    <circle cx="18.5" cy="7.5" r="0.6" fill="currentColor" />
  </svg>
);

export const IconUpload = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M12 15V4M7.5 8.5 12 4l4.5 4.5" />
    <path d="M4 15v5h16v-5" />
  </svg>
);

export const IconFlame = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M12 21c3.9 0 6.5-2.6 6.5-6.2 0-2.7-1.6-4.6-3-6.3-1.2-1.5-2.3-2.9-2.5-5-2.6 1.6-3.4 3.9-3.2 6.2-.8-.3-1.4-1-1.7-2.2-1.4 1.5-2.6 3.8-2.6 6.3C5.5 18.4 8.1 21 12 21Z" />
    <path d="M12 21c1.8 0 3-1.3 3-3.1 0-1.7-1.2-2.8-3-4.4-1.8 1.6-3 2.7-3 4.4C9 19.7 10.2 21 12 21Z" />
  </svg>
);

export const IconCheck = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4.5 12.5 10 18 19.5 6.5" />
  </svg>
);

export const IconCross = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M6 6l12 12M18 6 6 18" />
  </svg>
);

export const IconRefresh = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M19.5 12a7.5 7.5 0 1 1-2.2-5.3" />
    <path d="M19.7 3.5v4.2h-4.2" />
  </svg>
);

export const IconDoc = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M6 3h8l4 4v14H6z" />
    <path d="M14 3v4h4" />
    <path d="M9 12h6M9 15.5h6M9 8.5h2" />
  </svg>
);

export const IconPen = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4 20l1.2-4.2L16.5 4.5a1.8 1.8 0 0 1 2.6 0l.4.4a1.8 1.8 0 0 1 0 2.6L8.2 18.8 4 20Z" />
    <path d="M14.5 6.5l3 3" />
  </svg>
);

export const IconArrow = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4 12h15M13.5 5.5 20 12l-6.5 6.5" />
  </svg>
);

export const IconTrash = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M4.5 6.5h15M9.5 6V4h5v2" />
    <path d="M6.5 6.5 7.5 20h9l1-13.5" />
    <path d="M10.2 10v6M13.8 10v6" />
  </svg>
);

export const IconSearch = ({ className }: P) => (
  <svg {...base(className)}>
    <circle cx="10.5" cy="10.5" r="6" />
    <path d="M15.2 15.2 20 20" />
  </svg>
);

export const IconLayers = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M12 3.5 21 8l-9 4.5L3 8l9-4.5Z" />
    <path d="m3 12.5 9 4.5 9-4.5" />
    <path d="m3 16.5 9 4.5 9-4.5" />
  </svg>
);

export const IconAlert = ({ className }: P) => (
  <svg {...base(className)}>
    <path d="M12 3.5 22 20H2L12 3.5Z" />
    <path d="M12 10v4.5" />
    <circle cx="12" cy="17.2" r="0.6" fill="currentColor" />
  </svg>
);

export const IconClock = ({ className }: P) => (
  <svg {...base(className)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 6.5V12l4 2.5" />
  </svg>
);
