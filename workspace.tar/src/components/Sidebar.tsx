import type { FC } from "react";
import { useStore } from "../lib/store";
import { cx } from "./ui";
import { IconBank, IconCalendar, IconChart, IconHome, IconNotebook, IconTarget, IconUpload } from "./icons";

export type Tab = "home" | "weekly" | "mistakes" | "bank" | "stats" | "import";

export interface NavItem {
  key: Tab;
  label: string;
  en: string;
  icon: FC<{ className?: string }>;
}

export const NAV: NavItem[] = [
  { key: "home", label: "今日总览", en: "TODAY", icon: IconHome },
  { key: "weekly", label: "每周复盘", en: "WEEKLY", icon: IconCalendar },
  { key: "mistakes", label: "错题本", en: "MISTAKES", icon: IconNotebook },
  { key: "bank", label: "题库", en: "BANK", icon: IconBank },
  { key: "stats", label: "数据统计", en: "STATS", icon: IconChart },
  { key: "import", label: "导入 PDF", en: "IMPORT", icon: IconUpload },
];

export function Sidebar({ tab, setTab }: { tab: Tab; setTab: (t: Tab) => void }) {
  const { state, d } = useStore();

  const badge = (key: Tab): number => {
    if (key === "mistakes") return d.wrongQuestions.length;
    if (key === "weekly") return d.weekWrongIds.length;
    return 0;
  };

  return (
    <>
      {/* 桌面端侧栏 */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col bg-inkblue text-paper lg:flex">
        <button className="group flex items-center gap-3 px-5 pb-5 pt-7 text-left" onClick={() => setTab("home")}>
          <span className="font-display flex h-11 w-11 shrink-0 items-center justify-center bg-pen text-xl font-black text-paper shadow-[3px_3px_0_rgba(0,0,0,0.35)] transition-transform duration-200 group-hover:-rotate-6">
            批
          </span>
          <span>
            <span className="font-display block text-lg font-black leading-tight tracking-wide">红笔刷题</span>
            <span className="block text-[10px] tracking-[0.22em] text-paper/50">RED PEN · 题库引擎</span>
          </span>
        </button>

        <nav className="mt-2 flex-1 space-y-0.5 px-3">
          {NAV.map((item) => {
            const active = tab === item.key;
            const n = badge(item.key);
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                className={cx(
                  "group relative flex w-full items-center gap-3 px-3.5 py-2.5 text-left text-[13.5px] transition-all duration-150",
                  active ? "bg-paper/10 font-bold text-paper" : "text-paper/60 hover:translate-x-1 hover:text-paper",
                )}
              >
                <span
                  className={cx(
                    "absolute left-0 top-1/2 h-6 w-[3px] -translate-y-1/2 bg-pen transition-all duration-200",
                    active ? "opacity-100" : "opacity-0 group-hover:opacity-60",
                  )}
                />
                <Icon className={cx("h-[18px] w-[18px] shrink-0", active ? "text-pen" : "")} />
                <span className="flex-1">{item.label}</span>
                {n > 0 && (
                  <span className="bg-pen px-1.5 py-px font-display text-[11px] font-bold text-paper">{n}</span>
                )}
                <span className="hidden text-[9px] tracking-[0.18em] text-paper/30 xl:block">{item.en}</span>
              </button>
            );
          })}
        </nav>

        <div className="mx-3 mb-3 border-t border-paper/10 px-3 pb-4 pt-4 text-[11px] leading-relaxed text-paper/50">
          <div className="flex justify-between">
            <span>题库</span>
            <span className="font-display font-bold text-paper">{state.questions.length} 题</span>
          </div>
          <div className="mt-1 flex justify-between">
            <span>累计正确率</span>
            <span className="font-display font-bold text-paper">{(d.accuracy * 100).toFixed(1)}%</span>
          </div>
          <div className="mt-1 flex justify-between">
            <span>当前轮次</span>
            <span className="font-display font-bold text-paper">第 {state.cycle} 轮</span>
          </div>
          <p className="mt-3 text-[10px] leading-relaxed text-paper/35">标红即答案 · 每日 15 题 · 周复盘 · 99% 达标</p>
        </div>
      </aside>

      {/* 移动端顶栏 */}
      <div className="fixed inset-x-0 top-0 z-40 border-b border-line bg-card/95 backdrop-blur lg:hidden">
        <div className="flex items-center gap-2.5 px-4 pt-3">
          <span className="font-display flex h-8 w-8 items-center justify-center bg-pen text-base font-black text-paper">批</span>
          <span className="font-display text-base font-black">红笔刷题</span>
          <span className="ml-auto font-display text-xs text-pen">{state.questions.length} 题</span>
        </div>
        <div className="flex gap-1 overflow-x-auto px-2 py-2">
          {NAV.map((item) => {
            const active = tab === item.key;
            const n = badge(item.key);
            return (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                className={cx(
                  "flex shrink-0 items-center gap-1.5 px-3 py-1.5 text-[13px] font-medium transition-colors",
                  active ? "bg-ink text-paper" : "bg-paper-deep text-ink-soft",
                )}
              >
                {item.label}
                {n > 0 && <span className="bg-pen px-1 text-[10px] font-bold text-paper">{n}</span>}
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
}

export function TargetIcon() {
  return <IconTarget className="h-4 w-4" />;
}
