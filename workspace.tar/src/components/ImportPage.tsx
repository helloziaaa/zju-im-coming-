import { useCallback, useRef, useState } from "react";
import type { DragEvent } from "react";
import { parseLines, textToLines } from "../lib/parser";
import type { ParseResult } from "../lib/parser";
import { makeQuestion, normalizeStem, useStore } from "../lib/store";
import type { Tab } from "./Sidebar";
import { Chip, Reveal, SectionTitle, cx } from "./ui";
import { IconAlert, IconArrow, IconCheck, IconDoc, IconRefresh, IconUpload } from "./icons";

type Mode = "pdf" | "text";
type Phase = "idle" | "parsing" | "done" | "error";

const SAMPLE_TEXT = `1. 下列属于行政处罚种类的有？
A. 罚款
B. 行政拘留
C. 没收违法所得
D. 责令停产停业
答案：ABCD
解析：《行政处罚法》第九条规定了警告、罚款、没收违法所得、责令停产停业、行政拘留等行政处罚种类。

2. 下列属于刑罚主刑的有？
A. 管制
B. 拘役
C. 有期徒刑
D. 罚金
答案：ABC
解析：主刑包括管制、拘役、有期徒刑、无期徒刑、死刑；罚金属于附加刑。`;

export function ImportPage({ goto }: { goto: (t: Tab) => void }) {
  const { state, dispatch } = useStore();
  const [mode, setMode] = useState<Mode>("pdf");
  const [phase, setPhase] = useState<Phase>("idle");
  const [progress, setProgress] = useState({ page: 0, total: 0 });
  const [error, setError] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [result, setResult] = useState<ParseResult | null>(null);
  const [sourceName, setSourceName] = useState("");
  const [colorPipeline, setColorPipeline] = useState(true);
  const [text, setText] = useState("");
  const [imported, setImported] = useState<{ added: number; total: number } | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setPhase("idle");
    setResult(null);
    setError("");
    setImported(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const handleFile = useCallback(async (file: File) => {
    if (!/\.pdf$/i.test(file.name) && file.type !== "application/pdf") {
      setPhase("error");
      setError("请选择 PDF 文件（.pdf）");
      return;
    }
    setImported(null);
    setResult(null);
    setSourceName(file.name);
    setPhase("parsing");
    setProgress({ page: 0, total: 0 });
    try {
      const buf = await file.arrayBuffer();
      const { extractPdf } = await import("../lib/pdf");
      const ext = await extractPdf(buf, (page: number, total: number) => setProgress({ page, total }));
      setColorPipeline(ext.hasColorPipeline);
      const res = parseLines(ext.lines, ext.hasColorPipeline);
      if (res.questions.length === 0) {
        setPhase("error");
        setError(
          ext.hasColorPipeline
            ? "PDF 里能读到文字，但没识别出题目。请确认格式：题号行（1. / 1、）开头，选项以 A. B. 开头，答案写『答案：ABC』或将答案标红。"
            : "该 PDF 没有可提取的文字层（可能是扫描件/图片），请先用 OCR 转成文字版，或改用「文本粘贴」方式导入。",
        );
        return;
      }
      setResult(res);
      setPhase("done");
    } catch (e) {
      setPhase("error");
      setError(`解析失败：${e instanceof Error ? e.message.slice(0, 120) : "文件可能已损坏或加密"}`);
    }
  }, []);

  const handleText = () => {
    const lines = textToLines(text);
    if (lines.length === 0) return;
    setImported(null);
    setSourceName("文本粘贴");
    setColorPipeline(false);
    const res = parseLines(lines, false);
    if (res.questions.length === 0) {
      setPhase("error");
      setError("没有识别出题目：请检查是否有「1. 题干」「A. 选项」「答案：AB」这样的行。");
      return;
    }
    setResult(res);
    setPhase("done");
  };

  const confirmImport = () => {
    if (!result) return;
    const qs = result.valid.map((p) => makeQuestion(p, sourceName || "未命名来源"));
    const exist = new Set(state.questions.map((q) => normalizeStem(q.stem)));
    const fresh = qs.filter((q) => !exist.has(normalizeStem(q.stem)));
    dispatch({ type: "IMPORT", questions: qs });
    setImported({ added: fresh.length, total: state.questions.length + fresh.length });
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  return (
    <div className="space-y-6">
      <SectionTitle no="06" title="导入题目" extra={<span className="text-xs text-ink-faint">PDF 标红字体 = 答案</span>} />

      {/* 模式切换 */}
      <div className="flex gap-2">
        {(
          [
            ["pdf", "PDF 上传", "自动识别红色答案"],
            ["text", "文本粘贴", "用『答案：AB』标注"],
          ] as const
        ).map(([m, label, sub]) => (
          <button
            key={m}
            onClick={() => {
              setMode(m);
              reset();
            }}
            className={cx(
              "btn-press flex-1 border-2 p-4 text-left sm:flex-none sm:px-8",
              mode === m ? "border-ink bg-ink text-paper shadow-press" : "border-line bg-card text-ink hover:border-ink",
            )}
          >
            <p className="font-display text-base font-black">{label}</p>
            <p className={cx("mt-0.5 text-xs", mode === m ? "text-paper/60" : "text-ink-faint")}>{sub}</p>
          </button>
        ))}
      </div>

      {imported ? (
        /* 导入成功 */
        <Reveal>
          <div className="paper-card relative overflow-hidden p-8 text-center">
            <div className="absolute inset-y-0 left-0 w-1.5 bg-green" />
            <p className="font-display text-3xl font-black text-ink">
              已入库 <span className="text-green">{imported.added}</span> 题
            </p>
            <p className="mt-2 text-sm text-ink-soft">题库现有 {state.questions.length} 题 · 题干重复的题目已自动跳过</p>
            <div className="mt-6 flex justify-center gap-3">
              <button
                onClick={() => goto("home")}
                className="btn-press font-display inline-flex items-center gap-2 border-2 border-pen-deep bg-pen px-6 py-3 text-base font-black text-paper shadow-press"
              >
                去刷今日 15 题 <IconArrow className="h-4 w-4" />
              </button>
              <button onClick={reset} className="btn-press font-display border-2 border-ink bg-card px-6 py-3 text-base font-bold shadow-press-sm">
                继续导入
              </button>
            </div>
          </div>
        </Reveal>
      ) : phase === "parsing" ? (
        <div className="paper-card p-10 text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center border-2 border-pen text-pen">
            <IconDoc className="flame-pulse h-8 w-8" />
          </div>
          <p className="font-display text-lg font-black text-ink">正在读取 PDF…</p>
          <p className="mt-1 text-sm text-ink-soft">
            {progress.total > 0 ? `第 ${progress.page} / ${progress.total} 页 · 正在比对红色字体` : "打开文件中…"}
          </p>
          <div className="mx-auto mt-5 h-1.5 w-64 overflow-hidden bg-grid">
            <div
              className="h-full bg-pen transition-all duration-300"
              style={{ width: progress.total > 0 ? `${(progress.page / progress.total) * 100}%` : "12%" }}
            />
          </div>
        </div>
      ) : phase === "error" ? (
        <div className="paper-card border-l-4 border-l-pen p-8">
          <p className="flex items-center gap-2 font-display text-lg font-black text-pen">
            <IconAlert className="h-5 w-5" /> 导入遇到问题
          </p>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-ink-soft">{error}</p>
          <button onClick={reset} className="btn-press font-display mt-5 border-2 border-ink bg-card px-5 py-2.5 text-sm font-bold shadow-press-sm">
            <IconRefresh className="mr-1.5 inline h-4 w-4" /> 重新选择
          </button>
        </div>
      ) : phase === "done" && result ? (
        /* 解析结果预览 */
        <div className="space-y-5">
          <Reveal>
            <div className="paper-card flex flex-wrap items-center gap-x-6 gap-y-3 p-6">
              <div>
                <p className="text-[11px] font-bold tracking-[0.22em] text-ink-faint">来源 · {sourceName}</p>
                <p className="font-display mt-0.5 text-2xl font-black text-ink">
                  解析出 {result.questions.length} 题
                </p>
              </div>
              <div className="flex flex-wrap gap-2">
                <Chip tone="green">
                  <IconCheck className="h-3 w-3" /> 有效 {result.valid.length}
                </Chip>
                {result.invalid.length > 0 && <Chip tone="pen">无效 {result.invalid.length}</Chip>}
                <Chip tone={result.redDetected ? "pen" : "ink"}>{result.redDetected ? "检出红色答案" : "未发现红字"}</Chip>
              </div>
              <div className="ml-auto flex gap-2">
                <button onClick={reset} className="btn-press border-2 border-ink bg-card px-4 py-2.5 text-sm font-bold shadow-press-sm">
                  重新选择
                </button>
                <button
                  onClick={confirmImport}
                  disabled={result.valid.length === 0}
                  className="btn-press font-display border-2 border-pen-deep bg-pen px-5 py-2.5 text-sm font-black text-paper shadow-press disabled:cursor-not-allowed disabled:opacity-40"
                >
                  确认入库 {result.valid.length} 题
                </button>
              </div>
            </div>
          </Reveal>

          {!colorPipeline && mode === "pdf" && (
            <div className="flex items-start gap-2.5 border-2 border-amber bg-amber-soft px-4 py-3 text-[13px] leading-relaxed text-amber">
              <IconAlert className="mt-0.5 h-4 w-4 shrink-0" />
              该 PDF 未检出文字颜色信息，答案依赖「答案：XX」行识别。若题目原本靠标红给出答案，可能识别不到——建议改用带文字层的 PDF。
            </div>
          )}

          {/* 有效题预览 */}
          <div className="grid gap-3 sm:grid-cols-2">
            {result.valid.map((q, i) => (
              <Reveal key={i} delay={Math.min(i * 40, 400)}>
                <div className="paper-card h-full p-4">
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-display text-sm font-black text-pen">Q{q.num}</p>
                    <span className="font-display border-2 border-pen px-1.5 text-sm font-black text-pen">{q.answer.join("")}</span>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-[13px] font-medium leading-relaxed text-ink">{q.stem}</p>
                  <p className="mt-2 flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-ink-faint">
                    <span>{q.options.length} 个选项</span>
                    {q.explanation ? (
                      <span className="text-green">含解析</span>
                    ) : (
                      <span className="text-amber">无解析（批阅时显示“暂无解析”）</span>
                    )}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>

          {result.invalid.length > 0 && (
            <details className="paper-card p-5">
              <summary className="cursor-pointer font-display text-sm font-black text-pen">
                {result.invalid.length} 道无效题被跳过（点击展开原因）
              </summary>
              <ul className="mt-3 space-y-2">
                {result.invalid.map((q, i) => (
                  <li key={i} className="border border-dashed border-line bg-paper px-3 py-2 text-xs leading-relaxed text-ink-soft">
                    <b className="text-ink">第 {q.num} 题：</b>
                    {q.errors.join("；")}
                    {q.stem && <span className="text-ink-faint"> —— 「{q.stem.slice(0, 40)}」</span>}
                  </li>
                ))}
              </ul>
            </details>
          )}
        </div>
      ) : (
        /* 空闲：上传区 / 文本区 */
        <div className="grid gap-5 lg:grid-cols-5">
          <div className="lg:col-span-3">
            {mode === "pdf" ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                onClick={() => fileRef.current?.click()}
                className={cx(
                  "flex cursor-pointer flex-col items-center justify-center border-2 border-dashed p-12 text-center transition-all duration-200",
                  dragOver ? "scale-[1.01] border-pen bg-pen-soft" : "border-ink-faint bg-card hover:border-pen hover:bg-pen-soft/40",
                )}
              >
                <input
                  ref={fileRef}
                  type="file"
                  accept=".pdf,application/pdf"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleFile(f);
                  }}
                />
                <span className={cx("flex h-16 w-16 items-center justify-center border-2 bg-paper transition-colors", dragOver ? "border-pen text-pen" : "border-ink text-ink")}>
                  <IconUpload className="h-7 w-7" />
                </span>
                <p className="font-display mt-5 text-xl font-black text-ink">拖入 PDF，或点击选择</p>
                <p className="mt-2 max-w-sm text-sm leading-relaxed text-ink-soft">
                  在浏览器本地解析，不上传服务器。<span className="font-bold text-pen">红色字体会被识别为答案</span>，
                  也支持「答案：ABC」文本写法。
                </p>
              </div>
            ) : (
              <div className="paper-card p-5">
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder={SAMPLE_TEXT}
                  className="h-72 w-full resize-y border-2 border-line bg-paper p-4 font-mono text-[13px] leading-relaxed outline-none focus:border-ink"
                />
                <div className="mt-3 flex items-center gap-3">
                  <button
                    onClick={handleText}
                    disabled={text.trim().length === 0}
                    className="btn-press font-display border-2 border-pen-deep bg-pen px-6 py-2.5 text-sm font-black text-paper shadow-press disabled:cursor-not-allowed disabled:opacity-40"
                  >
                    解析文本
                  </button>
                  <button
                    onClick={() => setText(SAMPLE_TEXT)}
                    className="btn-press border-2 border-line bg-card px-4 py-2.5 text-sm font-bold text-ink-soft hover:border-ink hover:text-ink"
                  >
                    填入示例
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 格式说明 */}
          <Reveal delay={100} className="lg:col-span-2">
            <div className="paper-card h-full p-5 sm:p-6">
              <p className="font-display text-base font-black text-ink">识别格式</p>
              <ol className="mt-4 space-y-3.5 text-[13px] leading-relaxed text-ink-soft">
                <li className="flex gap-2.5">
                  <b className="font-display text-pen">1.</b>
                  <span>
                    题号行：<code className="bg-paper px-1 font-mono text-xs">1. / 1、/ 1．/ 第3题</code>
                  </span>
                </li>
                <li className="flex gap-2.5">
                  <b className="font-display text-pen">2.</b>
                  <span>
                    选项行：<code className="bg-paper px-1 font-mono text-xs">A. 选项内容</code>，支持 A–F
                  </span>
                </li>
                <li className="flex gap-2.5">
                  <b className="font-display text-pen">3.</b>
                  <span>
                    答案：<b className="text-pen">整行/字母标红</b>，或写
                    <code className="bg-paper px-1 font-mono text-xs">答案：ABC</code>、
                    <code className="bg-paper px-1 font-mono text-xs">【答案】ABC</code>
                  </span>
                </li>
                <li className="flex gap-2.5">
                  <b className="font-display text-pen">4.</b>
                  <span>
                    解析（可选）：<code className="bg-paper px-1 font-mono text-xs">解析：…</code>，批阅后随题展示
                  </span>
                </li>
              </ol>
              <div className="mt-5 border-2 border-line bg-paper p-3.5 font-mono text-[11.5px] leading-relaxed text-ink-soft">
                <p>1. 下列属于主刑的有？</p>
                <p>A. 管制</p>
                <p>B. 拘役</p>
                <p>C. 有期徒刑</p>
                <p>D. 罚金</p>
                <p className="font-bold text-pen">答案：ABC</p>
                <p>解析：罚金属于附加刑。</p>
              </div>
              <p className="mt-4 text-xs leading-relaxed text-ink-faint">
                不定项选择题：答案可以是 1 个或多个字母。重复题干会自动去重。
              </p>
            </div>
          </Reveal>
        </div>
      )}
    </div>
  );
}
